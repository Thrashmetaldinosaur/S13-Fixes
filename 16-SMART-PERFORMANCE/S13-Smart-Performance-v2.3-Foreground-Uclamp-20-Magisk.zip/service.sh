#!/system/bin/sh
# Called by Magisk at late_start service stage. One shot; no CPU-frequency sysfs writes.
MODDIR=${0%/*}
U=/dev/cpuctl/top-app/cpu.uclamp.min
LOG="$MODDIR/status.log"
log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }
n=0
until [ "$(getprop sys.boot_completed)" = 1 ]; do
  sleep 2; n=$((n+1))
  if [ "$n" -ge 90 ]; then log 'SKIP boot timeout'; exit 0; fi
done
sleep 12
[ "$(getprop ro.product.model)" = S13 ] || { log 'SKIP unexpected model'; exit 0; }
[ "$(getprop ro.product.device)" = YBD_C29_OLED ] || { log 'SKIP unexpected device'; exit 0; }
[ "$(getprop ro.build.display.id)" = S13_C29_EN_V1.6_20251121 ] || { log 'SKIP unexpected firmware'; exit 0; }
[ -r "$U" ] && [ -w "$U" ] || { log 'SKIP uclamp unavailable'; exit 0; }
mode=$(cat "$MODDIR/profile.conf" 2>/dev/null)
case "$mode" in balanced) desired=20.00;; *) desired=10.00;; esac
before=$(cat "$U" 2>/dev/null)
case "$before" in 10|10.00|20|20.00) ;; *) log "SKIP unexpected existing uclamp=$before"; exit 0;; esac
if [ "$before" = "$desired" ]; then
  log "BOOT verified profile=$mode uclamp=$before (already target)"
  exit 0
fi
if printf '%s\n' "$desired" > "$U" 2>/dev/null; then
  after=$(cat "$U" 2>/dev/null)
  if [ "$after" = "$desired" ]; then
    log "BOOT applied from=$before to=$after profile=$mode"
  else
    log "BOOT write did not persist from=$before requested=$desired actual=$after"
  fi
else
  log "BOOT write failed existing=$before target=$desired"
fi
