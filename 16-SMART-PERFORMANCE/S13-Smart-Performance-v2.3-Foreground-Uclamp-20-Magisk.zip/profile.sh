#!/system/bin/sh
# Usage: su -c 'sh /data/adb/modules/s13_adaptive_perf/profile.sh [status|balanced|observe]'
MODDIR=${0%/*}
U=/dev/cpuctl/top-app/cpu.uclamp.min
LOG="$MODDIR/status.log"
case "$1" in
  ''|status)
    echo 'version=2.3.0'
    printf 'saved_profile='; cat "$MODDIR/profile.conf" 2>/dev/null
    printf 'top_app_uclamp_min='; cat "$U" 2>/dev/null
    echo 'stock_top_app_uclamp_min=10.00'
    echo 'balanced_top_app_uclamp_min=20.00'
    echo 'cpu_frequency_floor=vendor-managed'
    echo 'controller=one-shot-on-boot (no background polling)'
    echo 'Note: vendor may subsequently reset the uclamp value; this package does not fight it.'
    exit 0 ;;
  balanced) target=20.00; mode=balanced ;;
  stock|observe) target=10.00; mode=observe ;;
  *) echo 'Usage: profile.sh status|balanced|observe' >&2; exit 2 ;;
esac
[ -r "$U" ] && [ -w "$U" ] || { echo 'uclamp path unavailable' >&2; exit 1; }
before=$(cat "$U" 2>/dev/null)
case "$before" in 10|10.00|20|20.00) ;; *) echo "Unexpected existing uclamp value: $before; no changes" >&2; exit 1;; esac
printf '%s\n' "$mode" > "$MODDIR/profile.conf" || exit 1
if [ "$before" != "$target" ]; then
  printf '%s\n' "$target" > "$U" || exit 1
fi
after=$(cat "$U" 2>/dev/null)
if [ "$after" != "$target" ]; then echo "Write did not persist: actual=$after" >&2; exit 1; fi
echo "$(date '+%Y-%m-%d %H:%M:%S') PROFILE old=$before new=$after mode=$mode" >> "$LOG"
echo "Active top-app uclamp: $after; saved profile: $mode"
