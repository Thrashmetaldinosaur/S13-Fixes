#!/system/bin/sh
ui_print '------------------------------------------'
ui_print ' S13 Smart Performance v2.3.0'
ui_print ' Foreground CPU utilization floor: 20%'
ui_print '------------------------------------------'
[ "$(getprop ro.product.model)" = 'S13' ] || abort 'Not S13. Aborting.'
[ "$(getprop ro.product.device)" = 'YBD_C29_OLED' ] || abort 'Unexpected device. Aborting.'
[ "$(getprop ro.build.display.id)" = 'S13_C29_EN_V1.6_20251121' ] || abort 'Firmware mismatch. Aborting.'
U=/dev/cpuctl/top-app/cpu.uclamp.min
[ -r "$U" ] && [ -w "$U" ] || abort 'Foreground uclamp sysfs path unavailable.'
CUR=$(cat "$U" 2>/dev/null)
case "$CUR" in 10|10.00|20|20.00) ;; *) abort "Unexpected top-app uclamp value $CUR; no changes made." ;; esac
for f in service.sh profile.sh uninstall.sh; do
  [ -s "$MODPATH/$f" ] || abort "Missing module file $f"
  set_perm "$MODPATH/$f" 0 0 0755
done
printf '%s\n' balanced > "$MODPATH/profile.conf" || abort 'Unable to save profile.'
set_perm "$MODPATH/profile.conf" 0 0 0644
ui_print ' Replaces s13_adaptive_perf v2.2.0 (same module ID)'
ui_print ' Existing 1GHz floor/controller removed'
ui_print ' Foreground uclamp: 10.00 stock -> 20.00 balanced'
ui_print ' CPU frequencies, schedutil, Power HAL: unchanged'
ui_print ' Thermal calibration and protection: unchanged'
ui_print ' Applied once after each boot; zero polling overhead'
ui_print ' Observe/stock mode restores 10.00 when requested'
ui_print ' Reboot to activate.'
