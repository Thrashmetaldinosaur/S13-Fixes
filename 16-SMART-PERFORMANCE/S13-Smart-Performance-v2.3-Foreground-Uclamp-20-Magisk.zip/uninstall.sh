#!/system/bin/sh
# Revert the known 20% uclamp setting if still present. No CPU clocks touched.
U=/dev/cpuctl/top-app/cpu.uclamp.min
if [ -w "$U" ]; then
  current=$(cat "$U" 2>/dev/null)
  [ "$current" = 20.00 ] || [ "$current" = 20 ] || exit 0
  printf '10.00\n' > "$U" 2>/dev/null || true
fi
