# S13 Smart Performance v2.3: Foreground Uclamp 20%

Built specifically for the user's confirmed **S13 / YBD_C29_OLED / S13_C29_EN_V1.6_20251121** running rooted Magisk. Replaces v2.2 because it uses the **same** Magisk module ID `s13_adaptive_perf`. It no longer tries to write `scaling_min_freq` every few seconds.

## What it changes

- At each boot, after Android completes starting, makes **one write** to `/dev/cpuctl/top-app/cpu.uclamp.min`: stock `10.00` -> moderate `20.00`. Only affects Android tasks assigned to the top-app cgroup.
- Preserves native `schedutil`, vendor Power HAL, clock floor and maximum (`819000`-`1500000` kHz), and the user's separate thermal module v1.2. No continuously running watchdog, no polling overhead.
- **A 20% minimum utilization clamp does NOT mean apps run 20% faster.** Actual performance improvement and power cost vary. A scheduler utilization clamp is not a GHz frequency clamp. It does not override a vendor thermal cap on maximum frequency, but higher utilization can still increase device heat.
- Applied once per boot; Android/firmware could rewrite it later. This module intentionally does not fight those changes. Use the status command to check.
- Strictly refuses unknown S13 firmware/CPU sysfs values rather than blindly writing.

## Usage

Install with Magisk (`magisk --install-module /data/local/tmp/FILENAME.zip`) and reboot. No second CPU controller should run; `s13_powerhal_ui_tune` should remain disabled.

Check after boot:

```sh
su -c 'sh /data/adb/modules/s13_adaptive_perf/profile.sh status'
```

Reapply 20% immediately and save for next boot:

```sh
su -c 'sh /data/adb/modules/s13_adaptive_perf/profile.sh balanced'
```

Return to 10% immediately, stay stock next boot:

```sh
su -c 'sh /data/adb/modules/s13_adaptive_perf/profile.sh observe'
```

**Disable/uninstall:** Magisk disable then reboot to prevent startup application; use `profile.sh observe` first to immediately return the active value to stock. Uninstall script also attempts to restore 10% if the device exposes it.

**Temperature:** The watch already has substantially elevated virtual-skin thresholds (51°C/56°C), especially risky while charging/on skin. This module does not increase thermal limits; keep hardware protection intact, and revert if uncomfortably warm.
