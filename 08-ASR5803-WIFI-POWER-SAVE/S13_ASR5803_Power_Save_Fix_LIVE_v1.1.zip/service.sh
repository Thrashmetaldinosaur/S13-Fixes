#!/system/bin/sh

MODDIR=${0%/*}
LOG="$MODDIR/asr5803-powersave.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') service.sh started" >> "$LOG"

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

# Let vendor Wi-Fi/Bluetooth services finish their normal boot initialization.
sleep 15
sh "$MODDIR/apply.sh"
