S13 ASR5803 Wi-Fi Power Save Fix v1.1

This version accounts for the S13's shared ASR5803 Wi-Fi/Bluetooth power rail.
Before reloading the Wi-Fi driver it cleanly disables Bluetooth and Wi-Fi,
then restores each radio to its prior state after the combo hardware is stable.

Driver parameters applied:
    ps_on=1
    PS_mode=1

Install in Magisk -> Modules -> Install from storage, then reboot.

Verification:
    adb shell su -c "cat /sys/module/asr5803/parameters/ps_on"
    adb shell su -c "cat /sys/module/asr5803/parameters/PS_mode"

Expected:
    Y
    1

Log:
    /data/adb/modules/s13_asr5803_powersave/asr5803-powersave.log

Recovery:
Disable/remove this module in Magisk and reboot. It does not modify the stock
kernel module on disk.
