#!/system/bin/sh

MODDIR=${0%/*}
sh "$MODDIR/apply.sh"

echo
echo "Current ASR5803 parameters:"
if [ -r /sys/module/asr5803/parameters/ps_on ]; then
  echo "ps_on=$(cat /sys/module/asr5803/parameters/ps_on)"
else
  echo "ps_on=missing"
fi
if [ -r /sys/module/asr5803/parameters/PS_mode ]; then
  echo "PS_mode=$(cat /sys/module/asr5803/parameters/PS_mode)"
else
  echo "PS_mode=missing"
fi

echo
echo "Bluetooth manager summary:"
dumpsys bluetooth_manager 2>/dev/null | grep -E "enabled:|state:" | head -n 10

echo
echo "Log: $MODDIR/asr5803-powersave.log"
