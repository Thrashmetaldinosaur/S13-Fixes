#!/system/bin/sh

MODDIR=${0%/*}
LOG="$MODDIR/asr5803-powersave.log"
MODULE="/vendor_dlkm/lib/modules/asr5803.ko"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

get_wifi_state() {
  WIFI_WAS_ON=0
  WIFI_SETTING="$(settings get global wifi_on 2>/dev/null)"
  case "$WIFI_SETTING" in
    1|2) WIFI_WAS_ON=1 ;;
  esac
  if cmd wifi status 2>/dev/null | grep -qi "enabled"; then
    WIFI_WAS_ON=1
  fi
}

get_bt_state() {
  BT_WAS_ON=0
  BT_SETTING="$(settings get global bluetooth_on 2>/dev/null)"
  [ "$BT_SETTING" = "1" ] && BT_WAS_ON=1
  if dumpsys bluetooth_manager 2>/dev/null | grep -q "enabled: true"; then
    BT_WAS_ON=1
  fi
}

current_values() {
  PS_ON_NOW="missing"
  PS_MODE_NOW="missing"
  [ -r /sys/module/asr5803/parameters/ps_on ] && \
    PS_ON_NOW="$(cat /sys/module/asr5803/parameters/ps_on 2>/dev/null)"
  [ -r /sys/module/asr5803/parameters/PS_mode ] && \
    PS_MODE_NOW="$(cat /sys/module/asr5803/parameters/PS_mode 2>/dev/null)"
}

restore_radios() {
  if [ "$WIFI_WAS_ON" = "1" ]; then
    log "Restoring Wi-Fi ON."
    svc wifi enable >/dev/null 2>&1
  else
    log "Leaving Wi-Fi OFF as it was before reload."
  fi

  # Give the shared ASR combo hardware time to settle before Bluetooth init.
  sleep 4

  if [ "$BT_WAS_ON" = "1" ]; then
    log "Restoring Bluetooth ON."
    svc bluetooth enable >/dev/null 2>&1
    sleep 3
  else
    log "Leaving Bluetooth OFF as it was before reload."
  fi
}

apply_fix() {
  log "Starting ASR5803 power-save apply."

  if [ ! -f "$MODULE" ]; then
    log "ERROR: $MODULE not found."
    return 1
  fi

  current_values
  log "Before: ps_on=$PS_ON_NOW PS_mode=$PS_MODE_NOW"

  if [ "$PS_ON_NOW" = "Y" ] && [ "$PS_MODE_NOW" = "1" ]; then
    log "Fix already active; nothing to do."
    return 0
  fi

  get_wifi_state
  get_bt_state
  log "Radio state before reload: wifi=$WIFI_WAS_ON bluetooth=$BT_WAS_ON"

  # ASR5803 Wi-Fi and Bluetooth share power on this device. Shut both down
  # cleanly before the Wi-Fi driver toggles the combo-chip power rail.
  svc bluetooth disable >/dev/null 2>&1
  sleep 3
  svc wifi disable >/dev/null 2>&1
  sleep 3

  if grep -q '^asr5803 ' /proc/modules 2>/dev/null; then
    log "Unloading asr5803."
    if ! rmmod asr5803 >>"$LOG" 2>&1; then
      log "ERROR: rmmod asr5803 failed."
      restore_radios
      return 1
    fi
  fi

  # The S13 needs several seconds for SDIO/power teardown to finish.
  sleep 7

  log "Loading asr5803 with ps_on=1 PS_mode=1."
  if ! insmod "$MODULE" ps_on=1 PS_mode=1 >>"$LOG" 2>&1; then
    log "Custom insmod failed; waiting and retrying once."
    sleep 5
    if ! insmod "$MODULE" ps_on=1 PS_mode=1 >>"$LOG" 2>&1; then
      log "ERROR: custom reload failed twice. Attempting stock reload."
      sleep 3
      if ! insmod "$MODULE" >>"$LOG" 2>&1; then
        log "ERROR: stock reload also failed. A reboot will restore the normal boot-time driver load."
        return 1
      fi
      log "Stock driver restored."
    fi
  fi

  current_values
  log "After: ps_on=$PS_ON_NOW PS_mode=$PS_MODE_NOW"

  restore_radios

  if [ "$PS_ON_NOW" = "Y" ] && [ "$PS_MODE_NOW" = "1" ]; then
    log "SUCCESS: ASR5803 power-save fix active."
    return 0
  fi

  log "WARNING: driver is loaded but requested parameters are not both active."
  return 1
}

apply_fix
exit $?
