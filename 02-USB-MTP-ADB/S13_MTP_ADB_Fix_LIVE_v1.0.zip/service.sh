#!/system/bin/sh

MODDIR=${0%/*}

# Run original S13 MTP+ADB boot configuration
sh "$MODDIR/boot_mtp.sh"

# Let USB settle, then start reconnect monitor
sleep 2

nohup sh "$MODDIR/reconnect.sh" \
    >/data/local/tmp/s13_mtp_reconnect_launcher.log \
    2>&1 </dev/null &