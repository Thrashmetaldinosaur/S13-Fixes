#!/system/bin/sh

STATEFILE=/sys/devices/virtual/android_usb/android0/state
LOG=/data/local/tmp/s13_mtp_reconnect.log
PIDFILE=/data/local/tmp/s13_mtp_reconnect.pid

while [ ! -r "$STATEFILE" ]; do
    sleep 1
done

echo $$ > "$PIDFILE"

LAST=$(cat "$STATEFILE" 2>/dev/null)
SAW_DISCONNECT=0

echo "$(date) watcher started state=$LAST" >> "$LOG"

while :; do
    STATE=$(cat "$STATEFILE" 2>/dev/null)

    if [ "$STATE" != "$LAST" ]; then
        echo "$(date '+%H:%M:%S') state=$STATE" >> "$LOG"

        if [ "$STATE" = "DISCONNECTED" ]; then
            SAW_DISCONNECT=1
        fi

        if [ "$STATE" = "CONFIGURED" ] && [ "$SAW_DISCONNECT" = "1" ]; then
            echo "$(date '+%H:%M:%S') reconnect detected" >> "$LOG"

            sleep 2

            am force-stop com.android.mtp

            am broadcast --user 0 \
                -n com.android.mtp/.MtpReceiver \
                -a android.hardware.usb.action.USB_STATE \
                --ez connected true \
                --ez configured false \
                --ez mtp true \
                --ez ptp false \
                --ez adb true \
                --ez unlocked true \
                --ez config_changed true \
                >> "$LOG" 2>&1

            sleep 1

            am broadcast --user 0 \
                -n com.android.mtp/.MtpReceiver \
                -a android.hardware.usb.action.USB_STATE \
                --ez connected true \
                --ez configured true \
                --ez mtp true \
                --ez ptp false \
                --ez adb true \
                --ez unlocked true \
                --ez config_changed false \
                >> "$LOG" 2>&1

            sleep 1

            am start-service --user 0 \
                -n com.android.mtp/.MtpService \
                --ez unlocked true \
                >> "$LOG" 2>&1

            SAW_DISCONNECT=0

            echo "$(date '+%H:%M:%S') MTP restart complete" >> "$LOG"
        fi

        LAST="$STATE"
    fi

    sleep 0.5
done