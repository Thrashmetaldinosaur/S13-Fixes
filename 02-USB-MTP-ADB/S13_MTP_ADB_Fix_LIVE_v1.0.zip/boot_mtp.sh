#!/system/bin/sh

LOG=/data/local/tmp/s13_mtp_boot.log
G=/config/usb_gadget/g1
C=$G/configs/b.1

exec >>"$LOG" 2>&1

echo
echo "========== S13 MTP BOOT FIX =========="
date
id

# Wait until Android has finished booting.
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 90 ]; do
    sleep 2
    i=$((i+1))
done

# Give vendor USB initialization a little more time.
sleep 5

# Wait for the ASR configfs gadget to exist.
i=0
while [ "$i" -lt 30 ]; do
    if [ -e "$G/UDC" ] &&
       [ -d "$G/functions/ffs.mtp" ] &&
       [ -d "$G/functions/ffs.adb" ]; then
        break
    fi

    sleep 2
    i=$((i+1))
done

if [ ! -e "$G/UDC" ]; then
    echo "ERROR: USB gadget did not appear."
    exit 1
fi

UDC=$(cat "$G/UDC" 2>/dev/null)

if [ -z "$UDC" ]; then
    UDC=c0900100.udc
fi

echo "UDC=$UDC"

echo
echo "=== RESET ANDROID MTP SERVICE ==="

am force-stop com.android.mtp

echo
echo "=== UNBIND STOCK USB GADGET ==="

printf '\n' > "$G/UDC"
sleep 2

echo
echo "=== REMOVE STOCK RNDIS/ADB LINKS ==="

rm -f "$C/function0"
rm -f "$C/function1"
rm -f "$C/function2"

rm -f "$C/f1"
rm -f "$C/f2"
rm -f "$C/f3"
rm -f "$C/f4"
rm -f "$C/f5"

echo
echo "=== RESET USB CLASS DESCRIPTORS ==="

echo 0 > "$G/bDeviceClass"
echo 0 > "$G/bDeviceSubClass"
echo 0 > "$G/bDeviceProtocol"

if [ -e "$G/os_desc/use" ]; then
    echo 0 > "$G/os_desc/use"
fi

echo
echo "=== INSTALL MTP + ADB ==="

ln -s "$G/functions/ffs.mtp" "$C/function0"
ln -s "$G/functions/ffs.adb" "$C/function1"

mkdir -p "$C/strings/0x409"
echo "mtp_adb" > "$C/strings/0x409/configuration"

echo
echo "=== INITIALIZE ANDROID MTP ==="

setprop sys.usb.ffs.mtp.ready 0

am broadcast --user 0 \
    -n com.android.mtp/.MtpReceiver \
    -a android.hardware.usb.action.USB_STATE \
    --ez connected true \
    --ez configured false \
    --ez mtp true \
    --ez ptp false \
    --ez adb true \
    --ez unlocked true \
    --ez config_changed true

sleep 2

echo
echo "=== BIND MTP + ADB GADGET ==="

echo "$UDC" > "$G/UDC"

sleep 4

echo
echo "=== NOTIFY ANDROID USB IS CONFIGURED ==="

am broadcast --user 0 \
    -n com.android.mtp/.MtpReceiver \
    -a android.hardware.usb.action.USB_STATE \
    --ez connected true \
    --ez configured true \
    --ez mtp true \
    --ez ptp false \
    --ez adb true \
    --ez unlocked true \
    --ez config_changed false

sleep 2

echo
echo "=== START REAL ANDROID MTP SERVICE ==="

am start-service --user 0 \
    -n com.android.mtp/.MtpService \
    --ez unlocked true

sleep 3

echo
echo "=== FINAL USB CONFIG ==="

ls -la "$C"

echo
echo "UDC:"
cat "$G/UDC"

echo
echo "MTP SERVICE:"
dumpsys activity services com.android.mtp | head -n 50

echo
echo "========== DONE =========="
