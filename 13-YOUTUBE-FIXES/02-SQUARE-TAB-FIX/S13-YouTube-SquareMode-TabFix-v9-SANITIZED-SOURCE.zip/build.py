#!/usr/bin/env python3
"""YouTube-only square mode fallback for bottom tab clicks on the S13."""
import struct, hashlib, zlib, zipfile, io, os, subprocess, pathlib, json
B=pathlib.Path(__file__).parent
apkbase=pathlib.Path('/mnt/data/YouTubeFullscreenFix.apk')

PKG='com.s13.youtubesquaremodefix'
H='Lcom/s13/youtubesquaremodefix/Hook;'
T='Lcom/s13/youtubesquaremodefix/Touch;'
P='Lcom/s13/youtubesquaremodefix/NavProbe;'

# Register classes and methods, fields. Protos are exact runtime descriptors.
fields=[
 ('Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;', 'packageName','Ljava/lang/String;'),
 ('Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;', 'classLoader','Ljava/lang/ClassLoader;'),
 ('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;', 'thisObject','Ljava/lang/Object;'),
 ('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;', 'args','[Ljava/lang/Object;'),
]
methods=[
 ('Ljava/lang/Object;','<init>','()V'),
 ('Lde/robv/android/xposed/XC_MethodHook;','<init>','()V'),
 (H,'<init>','()V'),(H,'handleLoadPackage','(Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;)V'),
 (T,'<init>','()V'),(T,'beforeHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V'),
 (T,'logTouch','(Landroid/view/MotionEvent;I)V'),
 (T,'logLayout','(Landroid/app/Activity;)V'),
 (T,'logView','(Ljava/lang/String;Landroid/view/View;)V'),
 (T,'logChildren','(Landroid/view/View;I)V'),
 (T,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V'),
 ('Ljava/lang/String;','equals','(Ljava/lang/Object;)Z'),
 ('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'),
 ('Lde/robv/android/xposed/XposedHelpers;','findAndHookMethod','(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;'),
 ('Landroid/app/Activity;','getContentResolver','()Landroid/content/ContentResolver;'),
 ('Landroid/app/Activity;','getResources','()Landroid/content/res/Resources;'),
 ('Landroid/app/Activity;','getWindow','()Landroid/view/Window;'),
 ('Landroid/content/res/Resources;','getIdentifier','(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I'),
 ('Landroid/view/Window;','getDecorView','()Landroid/view/View;'),
 ('Landroid/view/View;','findViewById','(I)Landroid/view/View;'),
 ('Landroid/view/View;','getLocationOnScreen','([I)V'),
 ('Landroid/view/View;','getWidth','()I'),
 ('Landroid/view/View;','getId','()I'),
 ('Landroid/view/View;','isClickable','()Z'),
 ('Landroid/view/View;','isEnabled','()Z'),
 ('Landroid/view/View;','getVisibility','()I'),
 ('Ljava/lang/Object;','getClass','()Ljava/lang/Class;'),
 ('Ljava/lang/Class;','getSimpleName','()Ljava/lang/String;'),
 ('Landroid/view/ViewGroup;','getChildCount','()I'),
 ('Landroid/view/ViewGroup;','getChildAt','(I)Landroid/view/View;'),
 ('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','getResult','()Ljava/lang/Object;'),
 ('Ljava/lang/Boolean;','booleanValue','()Z'),
 ('Landroid/view/View;','getHeight','()I'),
 ('Landroid/view/View;','getMeasuredWidth','()I'),
 ('Landroid/view/View;','getMeasuredHeight','()I'),
 ('Landroid/view/View;','isShown','()Z'),
 ('Landroid/view/View;','getGlobalVisibleRect','(Landroid/graphics/Rect;)Z'),
 ('Landroid/graphics/Rect;','<init>','()V'),
 ('Landroid/graphics/Rect;','toShortString','()Ljava/lang/String;'),
 ('Landroid/provider/Settings$System;','getInt','(Landroid/content/ContentResolver;Ljava/lang/String;I)I'),
 ('Landroid/view/MotionEvent;','getActionMasked','()I'),
 ('Landroid/view/MotionEvent;','getX','()F'),
 ('Landroid/view/MotionEvent;','getY','()F'),
 ('Landroid/view/MotionEvent;','getRawX','()F'),
 ('Landroid/view/MotionEvent;','getRawY','()F'),
 ('Ljava/lang/StringBuilder;','<init>','()V'),
 ('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'),
]

methods.extend([
 (P,'<init>','()V'),
 (P,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V'),
 ('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'),
 ('Landroid/view/View;','getLeft','()I'),
])
methods.extend([
 ('Landroid/view/MotionEvent;','getPointerCount','()I'),
 ('Landroid/view/MotionEvent;','getEventTime','()J'),
 ('Landroid/view/MotionEvent;','getDownTime','()J'),
 ('Landroid/view/View;','getRootView','()Landroid/view/View;'),
 ('Landroid/view/View;','performClick','()Z'),
 ('Ljava/lang/Integer;','valueOf','(I)Ljava/lang/Integer;'),
 ('Ljava/lang/Integer;','intValue','()I'),
 ('Lde/robv/android/xposed/XposedHelpers;','setAdditionalInstanceField','(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;'),
 ('Lde/robv/android/xposed/XposedHelpers;','getAdditionalInstanceField','(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;'),
])
classes=[(H,'Ljava/lang/Object;', ['Lde/robv/android/xposed/IXposedHookLoadPackage;']), (T,'Lde/robv/android/xposed/XC_MethodHook;',[]),(P,'Lde/robv/android/xposed/XC_MethodHook;',[])]

def shorty(t):
 return 'L' if t.startswith('L') or t.startswith('[') else t[0]
def parseproto(desc):
 assert desc.startswith('(')
 p=desc.index(')'); inside=desc[1:p]; ret=desc[p+1:]; res=[];i=0
 while i<len(inside):
  st=i
  while inside[i]=='[':i+=1
  if inside[i]=='L':i=inside.index(';',i)+1
  else:i+=1
  res.append(inside[st:i])
 return ret, tuple(res)

classes.sort(key=lambda x:x[0])
types=set()
for a,b,c in methods:
 types.add(a);ret,args=parseproto(c);types.add(ret);types.update(args)
for a,b,c in fields:types.update((a,c))
for a,b,ifaces in classes:
 types.update((a,b));types.update(ifaces)
for t in ['Landroid/view/ViewGroup;','Landroid/app/Activity;','Landroid/view/MotionEvent;','[Ljava/lang/Object;','[I','Landroid/graphics/Rect;','Ljava/lang/ClassLoader;']:
 types.add(t)
textstrings={
 'S13SquareDiag v6: DOWN mode=', ' local=(', ' raw=(', ' x=', ' y=',
 'S13SquareDiag v6: ', ' screen=(', ' size=(', ' measured=(',
 ' shown=', ' globalVisible=', ' rect=', ' missing',
 ', ', ')',
 'decor', 'bottom_bar_container', 'pivot_bar', 'id',
 'com.google.android.youtube',
 'com.google.android.apps.youtube.app.watchwhile.MainActivity',
 'watch_small_screen_stat','dispatchTouchEvent','Hook.java','Touch.java','NavProbe.java',
 'S13SquareDiag v6: MainActivity hook installed (NO TOUCH MODIFICATION)',
 'tree depth=', ' class=', ' id=', ' clickable=', ' enabled=', ' visibility=',
 'S13SquareDiag v6: MainActivity DOWN consumed=',
 'android.view.ViewGroup', 'android.view.View', 'performClick', 'PivotBar',
 'S13SquareNav v6: TAB dispatch left=', ' action=', ' localX=', ' localY=', ' consumed=',
 'S13SquareNav v6: TAB performClick left=', ' returned=',
 'S13SquareNav v6: framework hooks installed',
 'S13SquareFix v9: installed', 'S13SquareFix v9: arm=', 'S13SquareFix v9: original tab click', 'S13SquareFix v9: fallback tab=',
 's13DownTabV9','s13ClickSeenV9',
}
for m in methods:
 textstrings.add(m[1]); r,args=parseproto(m[2]); textstrings.add(shorty(r)+''.join(map(shorty,args)))
for f in fields:textstrings.add(f[1])
textstrings.update(types)
strings=sorted(textstrings)
sid={s:i for i,s in enumerate(strings)}
types=sorted(types,key=lambda s:sid[s]); tid={t:i for i,t in enumerate(types)}
proto_set={parseproto(x[2]) for x in methods}
protos=sorted(proto_set,key=lambda p:(tid[p[0]],tuple(tid[a] for a in p[1])))
pid={p:i for i,p in enumerate(protos)}
fields=sorted(fields,key=lambda x:(tid[x[0]],sid[x[1]],tid[x[2]])); fid={f:i for i,f in enumerate(fields)}
methods=sorted(methods,key=lambda x:(tid[x[0]],sid[x[1]],pid[parseproto(x[2])]))
mid={m:i for i,m in enumerate(methods)}

def ULEB(v):
 x=bytearray()
 while True:
  b=v&127;v>>=7
  if v:b|=128
  x.append(b)
  if not v:return bytes(x)

def put16(x):return struct.pack('<H',x)
def put32(x):return struct.pack('<I',x)

class ASM:
 def __init__(self):self.words=[];self.labels={};self.fix=[]
 def emit(self,*words):self.words.extend(w&0xffff for w in words)
 def mark(self,name):self.labels[name]=len(self.words)
 def const4(self,a,k):assert -8<=k<=7;self.emit(0x12 | ((a&15)<<8)|((k&15)<<12))
 def const16(self,a,k):self.emit(0x13 |(a<<8),k)
 def const32(self,a,n):self.emit(0x14|(a<<8),n&0xffff,(n>>16)&0xffff)
 def conststring(self,a,s):self.emit(0x1a|(a<<8),sid[s])
 def constclass(self,a,s):self.emit(0x1c|(a<<8),tid[s])
 def newinstance(self,a,s):self.emit(0x22|(a<<8),tid[s])
 def checkcast(self,a,s):self.emit(0x1f|(a<<8),tid[s])
 def instance_of(self,a,b,t):self.emit(0x20|(a<<8)|(b<<12),tid[t])
 def iget(self,a,b,f):self.emit(0x54|(a<<8)|(b<<12),fid[f])
 def aget(self,op,a,b,c):self.emit(op|(a<<8),b|(c<<8))
 def newarray(self,a,b,t):self.emit(0x23| (a<<8)|(b<<12),tid[t])
 def invoke(self,op,reg,method):
  assert len(reg)<=5 and max(reg or [0])<16
  g=reg[4] if len(reg)>4 else 0
  bits=sum(r<<(j*4) for j,r in enumerate(reg[:4]))
  self.emit(op | (len(reg)<<12)|(g<<8),mid[method],bits)
 def result(self,a,obj=False):self.emit((0x0c if obj else 0x0a)|(a<<8))
 def branch(self,op,a,b,label):
  n=len(self.words);self.fix.append((n,label));self.emit(op|(a<<8)|(b<<12),0)
 def branchz(self,op,a,label):n=len(self.words);self.fix.append((n,label));self.emit(op|(a<<8),0)
 def ret(self):self.emit(0x0e)
 def resultwords(self):
  for pos,key in self.fix:
   off=self.labels[key]-pos;assert -32768<=off<=32767
   self.words[pos+1]=off&0xffff
  return b''.join(put16(w) for w in self.words)

code={}
# Hook.<init>()
a=ASM(); a.invoke(0x70,[0],('Ljava/lang/Object;','<init>','()V'));a.ret()
code[(H,'<init>','()V')]=(1,1,1,a.resultwords())
# Install ONLY YouTube MainActivity.dispatchTouchEvent; no framework View hooks.
a=ASM()
a.conststring(0,'com.google.android.youtube')
a.iget(1,6,('Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;','packageName','Ljava/lang/String;'))
a.invoke(0x6e,[0,1],('Ljava/lang/String;','equals','(Ljava/lang/Object;)Z'));a.result(1)
a.branchz(0x39,1,'install');a.ret()
a.mark('install')
a.conststring(0,'com.google.android.apps.youtube.app.watchwhile.MainActivity')
a.iget(1,6,('Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;','classLoader','Ljava/lang/ClassLoader;'))
a.conststring(2,'dispatchTouchEvent')
a.constclass(3,'Landroid/view/MotionEvent;')
a.newinstance(4,T);a.invoke(0x70,[4],(T,'<init>','()V'))
a.emit(0x24|(2<<12),tid['[Ljava/lang/Object;'],0x43);a.result(3,True)
a.invoke(0x71,[0,1,2,3],('Lde/robv/android/xposed/XposedHelpers;','findAndHookMethod','(Ljava/lang/String;Ljava/lang/ClassLoader;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;'))
a.conststring(0,'S13SquareFix v9: installed')
a.invoke(0x71,[0],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.ret()
code[(H,'handleLoadPackage','(Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;)V')]=(7,2,4,a.resultwords())

a=ASM();a.invoke(0x70,[0],('Lde/robv/android/xposed/XC_MethodHook;','<init>','()V'));a.ret()
code[(T,'<init>','()V')]=(1,1,1,a.resultwords())

# logTouch: this=v8, event=v9, mode=v10, locals v0..v7.
a=ASM()
a.newinstance(0,'Ljava/lang/StringBuilder;');a.invoke(0x70,[0],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(1,'S13SquareDiag v6: DOWN mode=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0,10],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(1,' local=(');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getX','()F'));a.result(2);a.invoke(0x6e,[0,2],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.conststring(1,', ');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getY','()F'));a.result(2);a.invoke(0x6e,[0,2],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.conststring(1,')');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(1,' raw=(');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getRawX','()F'));a.result(2);a.invoke(0x6e,[0,2],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.conststring(1,', ');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getRawY','()F'));a.result(2);a.invoke(0x6e,[0,2],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.conststring(1,')');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(1,True)
a.invoke(0x71,[1],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'));a.ret()
code[(T,'logTouch','(Landroid/view/MotionEvent;I)V')]=(11,3,2,a.resultwords())

# logView: this=v10,label=v11,view=v12; locals v0..v9.
# Prints on-screen coordinates, laid out and measured sizes, actual visible rectangle.
a=ASM()
a.branchz(0x38,12,'missing')
a.const4(2,2);a.newarray(1,2,'[I')
a.invoke(0x6e,[12,1],('Landroid/view/View;','getLocationOnScreen','([I)V'))
a.newinstance(4,'Landroid/graphics/Rect;');a.invoke(0x70,[4],('Landroid/graphics/Rect;','<init>','()V'))
a.invoke(0x6e,[12,4],('Landroid/view/View;','getGlobalVisibleRect','(Landroid/graphics/Rect;)Z'));a.result(5)
a.newinstance(0,'Ljava/lang/StringBuilder;');a.invoke(0x70,[0],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(3,'S13SquareDiag v6: ');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0,11],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(3,' screen=(');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.const4(2,0);a.aget(0x44,3,1,2);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,', ');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.const4(2,1);a.aget(0x44,3,1,2);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,')');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(3,' size=(');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[12],('Landroid/view/View;','getWidth','()I'));a.result(3);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,', ');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[12],('Landroid/view/View;','getHeight','()I'));a.result(3);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,')');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(3,' measured=(');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[12],('Landroid/view/View;','getMeasuredWidth','()I'));a.result(3);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,', ');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[12],('Landroid/view/View;','getMeasuredHeight','()I'));a.result(3);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,')');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(3,' shown=');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[12],('Landroid/view/View;','isShown','()Z'));a.result(3);a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.conststring(3,' globalVisible=');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0,5],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.conststring(3,' rect=');a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[4],('Landroid/graphics/Rect;','toShortString','()Ljava/lang/String;'));a.result(3,True)
a.invoke(0x6e,[0,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(3,True)
a.invoke(0x71,[3],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'));a.ret()
a.mark('missing')
a.newinstance(0,'Ljava/lang/StringBuilder;');a.invoke(0x70,[0],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(1,'S13SquareDiag v6: ');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0,11],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(1,' missing');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(1,True)
a.invoke(0x71,[1],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'));a.ret()
code[(T,'logView','(Ljava/lang/String;Landroid/view/View;)V')]=(13,3,4,a.resultwords())

# logChildren(this=v7, view=v8, depth=v9); only read properties; no mutations.
a=ASM()
a.branchz(0x38,8,'done')
a.const4(5,4)
a.branch(0x35,9,5,'done')  # depth >= 4
# Build a descriptive child label with clickable/enabled info.
a.newinstance(0,'Ljava/lang/StringBuilder;');a.invoke(0x70,[0],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(1,'tree depth=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0,9],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(1,' class=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[8],('Ljava/lang/Object;','getClass','()Ljava/lang/Class;'));a.result(1,True)
a.invoke(0x6e,[1],('Ljava/lang/Class;','getSimpleName','()Ljava/lang/String;'));a.result(1,True)
a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.conststring(1,' id=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[8],('Landroid/view/View;','getId','()I'));a.result(1)
a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(1,' clickable=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[8],('Landroid/view/View;','isClickable','()Z'));a.result(1)
a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.conststring(1,' enabled=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[8],('Landroid/view/View;','isEnabled','()Z'));a.result(1)
a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.conststring(1,' visibility=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[8],('Landroid/view/View;','getVisibility','()I'));a.result(1)
a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(1,True)
a.invoke(0x6e,[7,1,8],(T,'logView','(Ljava/lang/String;Landroid/view/View;)V'))
# Only recurse for ViewGroups, max 10 children per parent.
a.instance_of(1,8,'Landroid/view/ViewGroup;')
a.branchz(0x38,1,'done')
a.emit(0x07 | (3<<8) | (8<<12));a.checkcast(3,'Landroid/view/ViewGroup;')
a.invoke(0x6e,[3],('Landroid/view/ViewGroup;','getChildCount','()I'));a.result(4)
a.const4(2,0);a.const16(5,10)
a.mark('loop')
a.branch(0x35,2,4,'done')
a.branch(0x35,2,5,'done')
a.invoke(0x6e,[3,2],('Landroid/view/ViewGroup;','getChildAt','(I)Landroid/view/View;'));a.result(6,True)
a.emit(0xd8 | (1<<8),9 | (1<<8))  # add-int/lit8 v1,v9,1
a.invoke(0x6e,[7,6,1],(T,'logChildren','(Landroid/view/View;I)V'))
a.emit(0xd8 | (2<<8),2 | (1<<8)) # add-int/lit8 v2,v2,1
a.fix.append((len(a.words),'loop'));a.emit(0x29,0) # goto/16
a.mark('done');a.ret()
code[(T,'logChildren','(Landroid/view/View;I)V')]=(10,3,4,a.resultwords())

# logLayout: this=v6,activity=v7; locals v0..v5.
a=ASM()
a.invoke(0x6e,[7],('Landroid/app/Activity;','getWindow','()Landroid/view/Window;'));a.result(0,True)
a.invoke(0x6e,[0],('Landroid/view/Window;','getDecorView','()Landroid/view/View;'));a.result(1,True)
a.conststring(2,'decor');a.invoke(0x6e,[6,2,1],(T,'logView','(Ljava/lang/String;Landroid/view/View;)V'))
a.invoke(0x6e,[7],('Landroid/app/Activity;','getResources','()Landroid/content/res/Resources;'));a.result(0,True)
a.conststring(3,'id');a.conststring(4,'com.google.android.youtube')
a.conststring(2,'bottom_bar_container');a.invoke(0x6e,[0,2,3,4],('Landroid/content/res/Resources;','getIdentifier','(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I'));a.result(2)
a.invoke(0x6e,[1,2],('Landroid/view/View;','findViewById','(I)Landroid/view/View;'));a.result(2,True)
a.conststring(5,'bottom_bar_container');a.invoke(0x6e,[6,5,2],(T,'logView','(Ljava/lang/String;Landroid/view/View;)V'))
a.conststring(2,'pivot_bar');a.invoke(0x6e,[0,2,3,4],('Landroid/content/res/Resources;','getIdentifier','(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I'));a.result(2)
a.invoke(0x6e,[1,2],('Landroid/view/View;','findViewById','(I)Landroid/view/View;'));a.result(2,True)
a.conststring(5,'pivot_bar');a.invoke(0x6e,[6,5,2],(T,'logView','(Ljava/lang/String;Landroid/view/View;)V'))
a.const4(3,0);a.invoke(0x6e,[6,2,3],(T,'logChildren','(Landroid/view/View;I)V'))
a.ret()
code[(T,'logLayout','(Landroid/app/Activity;)V')]=(8,2,4,a.resultwords())

# beforeHookedMethod: only ACTION_DOWN; no setResult, no MotionEvent transforms.
a=ASM()
a.iget(0,7,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','args','[Ljava/lang/Object;'))
a.const4(1,0);a.aget(0x46,0,0,1);a.checkcast(0,'Landroid/view/MotionEvent;')
a.invoke(0x6e,[0],('Landroid/view/MotionEvent;','getActionMasked','()I'));a.result(1)
a.branchz(0x39,1,'done')
a.iget(1,7,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'))
a.checkcast(1,'Landroid/app/Activity;')
a.invoke(0x6e,[1],('Landroid/app/Activity;','getContentResolver','()Landroid/content/ContentResolver;'));a.result(2,True)
a.conststring(3,'watch_small_screen_stat');a.const4(4,0)
a.invoke(0x71,[2,3,4],('Landroid/provider/Settings$System;','getInt','(Landroid/content/ContentResolver;Ljava/lang/String;I)I'));a.result(3)
a.invoke(0x6e,[6,0,3],(T,'logTouch','(Landroid/view/MotionEvent;I)V'))
a.invoke(0x6e,[6,1],(T,'logLayout','(Landroid/app/Activity;)V'))
a.mark('done');a.ret()
code[(T,'beforeHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(8,2,4,a.resultwords())

# Log whether YouTube's MainActivity dispatch handled the DOWN event.
a=ASM()
a.iget(0,8,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','args','[Ljava/lang/Object;'))
a.const4(1,0);a.aget(0x46,0,0,1);a.checkcast(0,'Landroid/view/MotionEvent;')
a.invoke(0x6e,[0],('Landroid/view/MotionEvent;','getActionMasked','()I'));a.result(1)
a.branchz(0x39,1,'done')
a.invoke(0x6e,[8],('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','getResult','()Ljava/lang/Object;'));a.result(1,True)
a.checkcast(1,'Ljava/lang/Boolean;')
a.invoke(0x6e,[1],('Ljava/lang/Boolean;','booleanValue','()Z'));a.result(2)
a.newinstance(0,'Ljava/lang/StringBuilder;');a.invoke(0x70,[0],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(1,'S13SquareDiag v6: MainActivity DOWN consumed=');a.invoke(0x6e,[0,1],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0,2],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[0],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(1,True)
a.invoke(0x71,[1],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.mark('done');a.ret()
code[(T,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(9,2,3,a.resultwords())



# NavProbe: read-only instrumentation of individual clickable tab event dispatch and performClick.
# Every log is filtered to descendants whose grandparent is PivotBar.
a=ASM();a.invoke(0x70,[0],('Lde/robv/android/xposed/XC_MethodHook;','<init>','()V'));a.ret()
code[(P,'<init>','()V')]=(1,1,1,a.resultwords())

# v15=param, v14=this, v0..v13 temps.
a=ASM()
a.iget(0,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'))
a.checkcast(0,'Landroid/view/View;')
a.invoke(0x6e,[0],('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'));a.result(1,True)
a.instance_of(2,1,'Landroid/view/View;');a.branchz(0x38,2,'done')
a.checkcast(1,'Landroid/view/View;')
a.invoke(0x6e,[1],('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'));a.result(1,True)
a.instance_of(2,1,'Landroid/view/View;');a.branchz(0x38,2,'done')
a.checkcast(1,'Landroid/view/View;')
a.invoke(0x6e,[1],('Ljava/lang/Object;','getClass','()Ljava/lang/Class;'));a.result(2,True)
a.invoke(0x6e,[2],('Ljava/lang/Class;','getSimpleName','()Ljava/lang/String;'));a.result(2,True)
a.conststring(3,'PivotBar')
a.invoke(0x6e,[3,2],('Ljava/lang/String;','equals','(Ljava/lang/Object;)Z'));a.result(4)
a.branchz(0x38,4,'done')
# only clickable tabs beneath PivotBar, each 116/117 x 55
a.invoke(0x6e,[0],('Landroid/view/View;','isClickable','()Z'));a.result(4)
a.branchz(0x38,4,'done')
a.invoke(0x6e,[0],('Landroid/view/View;','getLeft','()I'));a.result(5)
a.iget(6,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','args','[Ljava/lang/Object;'))
a.emit(0x21|(7<<8)|(6<<12))  # array-length v7,v6
a.branchz(0x38,7,'click')
# Android ViewGroup.dispatchTouchEvent(MotionEvent). Skip ACTION_MOVE=2.
a.const4(8,0);a.aget(0x46,9,6,8);a.checkcast(9,'Landroid/view/MotionEvent;')
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getActionMasked','()I'));a.result(7)
a.const4(8,2);a.branch(0x32,7,8,'done')
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getX','()F'));a.result(10)
a.invoke(0x6e,[9],('Landroid/view/MotionEvent;','getY','()F'));a.result(11)
a.invoke(0x6e,[15],('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','getResult','()Ljava/lang/Object;'));a.result(8,True)
a.checkcast(8,'Ljava/lang/Boolean;')
a.invoke(0x6e,[8],('Ljava/lang/Boolean;','booleanValue','()Z'));a.result(8)
a.newinstance(3,'Ljava/lang/StringBuilder;');a.invoke(0x70,[3],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(4,'S13SquareNav v6: TAB dispatch left=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,5],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(4,' action=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,7],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(4,' localX=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,10],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.conststring(4,' localY=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,11],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.conststring(4,' consumed=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,8],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(4,True)
a.invoke(0x71,[4],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.ret()
a.mark('click')
a.invoke(0x6e,[15],('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','getResult','()Ljava/lang/Object;'));a.result(8,True)
a.checkcast(8,'Ljava/lang/Boolean;')
a.invoke(0x6e,[8],('Ljava/lang/Boolean;','booleanValue','()Z'));a.result(8)
a.newinstance(3,'Ljava/lang/StringBuilder;');a.invoke(0x70,[3],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(4,'S13SquareNav v6: TAB performClick left=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,5],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(4,' returned=')
a.invoke(0x6e,[3,4],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3,8],('Ljava/lang/StringBuilder;','append','(Z)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[3],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(4,True)
a.invoke(0x71,[4],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.mark('done');a.ret()
code[(P,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(16,2,3,a.resultwords())

# --- S13 v7 guarded tab fallback ---
# Both callbacks have v14=this, v15=MethodHookParam, v0..v13 locals.
# Shared helper emitter to calculate the 1-based tab index from a MotionEvent.
# Returns in v8; branches to skip for any coordinates outside 466x466 nav (y 411..465).
def emit_tab_index(a, evreg, skip):
    a.invoke(0x6e,[evreg],('Landroid/view/MotionEvent;','getX','()F'));a.result(4)
    a.emit(0x87 | (4<<8) | (4<<12))  # float-to-int v4, v4
    a.const4(7,0);a.branch(0x34,4,7,skip)  # x<0
    a.const16(7,466);a.branch(0x35,4,7,skip) # x>=466
    a.invoke(0x6e,[evreg],('Landroid/view/MotionEvent;','getY','()F'));a.result(5)
    a.emit(0x87 | (5<<8) | (5<<12))
    a.const16(7,411);a.branch(0x34,5,7,skip) # y<411
    a.const16(7,466);a.branch(0x35,5,7,skip) # y>=466
    a.const16(7,116);a.branch(0x34,4,7,'tab1')
    a.const16(7,232);a.branch(0x34,4,7,'tab2')
    a.const16(7,349);a.branch(0x34,4,7,'tab3')
    a.const4(8,4);a.branchz(0x38,8,'tabready') # unconditional? WRONG branchz if zero. replaced below
    a.mark('tab1');a.const4(8,1);a.mark('tab2')

# Before Activity.dispatchTouchEvent: capture DOWN only when square mode and tab hit.
a=ASM()
a.iget(0,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'))
a.checkcast(0,'Landroid/app/Activity;')
a.iget(1,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','args','[Ljava/lang/Object;'))
a.const4(3,0);a.aget(0x46,2,1,3);a.checkcast(2,'Landroid/view/MotionEvent;')
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getActionMasked','()I'));a.result(3)
a.branchz(0x39,3,'done') # if != ACTION_DOWN: skip
a.invoke(0x6e,[0],('Landroid/app/Activity;','getContentResolver','()Landroid/content/ContentResolver;'));a.result(3,True)
a.conststring(4,'watch_small_screen_stat');a.const4(5,0)
a.invoke(0x71,[3,4,5],('Landroid/provider/Settings$System;','getInt','(Landroid/content/ContentResolver;Ljava/lang/String;I)I'));a.result(3)
a.const4(7,1);a.branch(0x33,3,7,'done') # mode!=1
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getPointerCount','()I'));a.result(3)
a.const4(7,1);a.branch(0x33,3,7,'done')
# tab geometry

# Injected code: tab x in [0,466), y in [411,466)
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getX','()F'));a.result(4)
a.emit(0x87 | (4<<8) | (4<<12))
a.const4(7,0);a.branch(0x34,4,7,'done')
a.const16(7,466);a.branch(0x35,4,7,'done')
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getY','()F'));a.result(5)
a.emit(0x87 | (5<<8) | (5<<12))
a.const16(7,411);a.branch(0x34,5,7,'done')
a.const16(7,466);a.branch(0x35,5,7,'done')
a.const16(7,116);a.branch(0x34,4,7,'t1')
a.const16(7,232);a.branch(0x34,4,7,'t2')
a.const16(7,349);a.branch(0x34,4,7,'t3')
a.const4(8,4);a.branchz(0x39,8,'tready') # if nonzero, jump
# label jump from t4 via if-nez: a.branchz(op=0x39)
a.mark('t1');a.const4(8,1);a.branchz(0x39,8,'tready')
a.mark('t2');a.const4(8,2);a.branchz(0x39,8,'tready')
a.mark('t3');a.const4(8,3)
a.mark('tready')
a.invoke(0x6e,[0],('Landroid/app/Activity;','getWindow','()Landroid/view/Window;'));a.result(9,True)
a.invoke(0x6e,[9],('Landroid/view/Window;','getDecorView','()Landroid/view/View;'));a.result(9,True)
a.invoke(0x71,[8],('Ljava/lang/Integer;','valueOf','(I)Ljava/lang/Integer;'));a.result(10,True)
a.conststring(11,'s13DownTabV9')
a.invoke(0x71,[9,11,10],('Lde/robv/android/xposed/XposedHelpers;','setAdditionalInstanceField','(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;'))
a.newinstance(1,'Ljava/lang/StringBuilder;');a.invoke(0x70,[1],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(3,'S13SquareFix v9: arm=');a.invoke(0x6e,[1,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[1,8],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[1],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(1,True)
a.invoke(0x71,[1],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.mark('done');a.ret()
code[(T,'beforeHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(16,2,3,a.resultwords())

# After Activity.dispatchTouchEvent: for ACTION_UP, only when square mode and no native click,
# invoke the target tab's original performClick. Only 1-pointer taps under 650ms.
a=ASM()
a.iget(0,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'))
a.checkcast(0,'Landroid/app/Activity;')
a.iget(1,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','args','[Ljava/lang/Object;'))
a.const4(3,0);a.aget(0x46,2,1,3);a.checkcast(2,'Landroid/view/MotionEvent;')
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getActionMasked','()I'));a.result(3)
a.const4(7,1);a.branch(0x33,3,7,'done') # not ACTION_UP
# mode
a.invoke(0x6e,[0],('Landroid/app/Activity;','getContentResolver','()Landroid/content/ContentResolver;'));a.result(3,True)
a.conststring(4,'watch_small_screen_stat');a.const4(5,0)
a.invoke(0x71,[3,4,5],('Landroid/provider/Settings$System;','getInt','(Landroid/content/ContentResolver;Ljava/lang/String;I)I'));a.result(3)
a.const4(7,1);a.branch(0x33,3,7,'done')
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getPointerCount','()I'));a.result(3)
a.const4(7,1);a.branch(0x33,3,7,'done')
# duration <650ms; event times are 64-bit long in register pairs.
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getEventTime','()J'));a.emit(0x0b|(10<<8))
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getDownTime','()J'));a.emit(0x0b|(12<<8))
a.emit(0x9c | (10<<8), 10|(12<<8)) # sub-long v10,v10,v12
# long-to-int v10, v10 (opcode 0x84)
a.emit(0x84 | (10<<8) | (10<<12))
a.const16(11,650);a.branch(0x35,10,11,'done')
# up index
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getX','()F'));a.result(4)
a.emit(0x87 | (4<<8) | (4<<12))
a.const4(7,0);a.branch(0x34,4,7,'done')
a.const16(7,466);a.branch(0x35,4,7,'done')
a.invoke(0x6e,[2],('Landroid/view/MotionEvent;','getY','()F'));a.result(5)
a.emit(0x87 | (5<<8) | (5<<12))
a.const16(7,411);a.branch(0x34,5,7,'done')
a.const16(7,466);a.branch(0x35,5,7,'done')
a.const16(7,116);a.branch(0x34,4,7,'t1')
a.const16(7,232);a.branch(0x34,4,7,'t2')
a.const16(7,349);a.branch(0x34,4,7,'t3')
a.const4(8,4);a.branchz(0x39,8,'tready')
a.mark('t1');a.const4(8,1);a.branchz(0x39,8,'tready')
a.mark('t2');a.const4(8,2);a.branchz(0x39,8,'tready')
a.mark('t3');a.const4(8,3)
a.mark('tready')
# retrieve decor and corresponding DOWN marker
a.invoke(0x6e,[0],('Landroid/app/Activity;','getWindow','()Landroid/view/Window;'));a.result(9,True)
a.invoke(0x6e,[9],('Landroid/view/Window;','getDecorView','()Landroid/view/View;'));a.result(9,True)
a.conststring(11,'s13DownTabV9')
a.invoke(0x71,[9,11],('Lde/robv/android/xposed/XposedHelpers;','getAdditionalInstanceField','(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;'));a.result(10,True)
a.branchz(0x38,10,'done')
a.checkcast(10,'Ljava/lang/Integer;')
a.invoke(0x6e,[10],('Ljava/lang/Integer;','intValue','()I'));a.result(10)
a.branch(0x33,10,8,'done')
# clear marker BEFORE triggering fallback
a.const4(7,0);a.invoke(0x71,[7],('Ljava/lang/Integer;','valueOf','(I)Ljava/lang/Integer;'));a.result(10,True)
a.invoke(0x71,[9,11,10],('Lde/robv/android/xposed/XposedHelpers;','setAdditionalInstanceField','(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;'))
a.mark('locate')
a.invoke(0x6e,[0],('Landroid/app/Activity;','getResources','()Landroid/content/res/Resources;'));a.result(1,True)
a.conststring(2,'pivot_bar');a.conststring(3,'id');a.conststring(4,'com.google.android.youtube')
a.invoke(0x6e,[1,2,3,4],('Landroid/content/res/Resources;','getIdentifier','(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I'));a.result(6)
a.branchz(0x38,6,'done')
a.invoke(0x6e,[9,6],('Landroid/view/View;','findViewById','(I)Landroid/view/View;'));a.result(1,True)
a.branchz(0x38,1,'done')
a.checkcast(1,'Landroid/view/ViewGroup;')
a.const4(7,0);a.invoke(0x6e,[1,7],('Landroid/view/ViewGroup;','getChildAt','(I)Landroid/view/View;'));a.result(1,True)
a.branchz(0x38,1,'done')
a.checkcast(1,'Landroid/view/ViewGroup;')
a.const4(7,1)
a.emit(0x91 | (8<<8),8 | (7<<8)) # sub-int v8,v8,v7 (index 1 -> child 0)
a.invoke(0x6e,[1,8],('Landroid/view/ViewGroup;','getChildAt','(I)Landroid/view/View;'));a.result(1,True)
a.branchz(0x38,1,'done')
a.invoke(0x6e,[1],('Landroid/view/View;','isEnabled','()Z'));a.result(7)
a.branchz(0x38,7,'done')
a.invoke(0x6e,[1],('Landroid/view/View;','isShown','()Z'));a.result(7)
a.branchz(0x38,7,'done')
a.invoke(0x6e,[1],('Landroid/view/View;','isClickable','()Z'));a.result(7)
a.branchz(0x38,7,'done')
# log before triggering normal click handler
a.newinstance(2,'Ljava/lang/StringBuilder;');a.invoke(0x70,[2],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(3,'S13SquareFix v9: fallback tab=');a.invoke(0x6e,[2,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[2,8],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[2],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(2,True)
a.invoke(0x71,[2],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.invoke(0x6e,[1],('Landroid/view/View;','performClick','()Z'));a.result(7)
a.mark('done');a.ret()
code[(T,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(16,2,4,a.resultwords())

# After a native tab click, record it on same decor to prevent double nav.
a=ASM()
a.iget(0,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'))
a.checkcast(0,'Landroid/view/View;')
a.invoke(0x6e,[0],('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'));a.result(1,True)
a.instance_of(2,1,'Landroid/view/View;');a.branchz(0x38,2,'done')
a.checkcast(1,'Landroid/view/View;')
a.invoke(0x6e,[1],('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'));a.result(1,True)
a.instance_of(2,1,'Landroid/view/View;');a.branchz(0x38,2,'done')
a.checkcast(1,'Landroid/view/View;')
a.invoke(0x6e,[1],('Ljava/lang/Object;','getClass','()Ljava/lang/Class;'));a.result(2,True)
a.invoke(0x6e,[2],('Ljava/lang/Class;','getSimpleName','()Ljava/lang/String;'));a.result(2,True)
a.conststring(3,'PivotBar');a.invoke(0x6e,[3,2],('Ljava/lang/String;','equals','(Ljava/lang/Object;)Z'));a.result(4)
a.branchz(0x38,4,'done')
a.invoke(0x6e,[0],('Landroid/view/View;','getRootView','()Landroid/view/View;'));a.result(1,True)
a.const4(2,1);a.invoke(0x71,[2],('Ljava/lang/Integer;','valueOf','(I)Ljava/lang/Integer;'));a.result(2,True)
a.conststring(3,'s13ClickSeenV9')
a.invoke(0x71,[1,3,2],('Lde/robv/android/xposed/XposedHelpers;','setAdditionalInstanceField','(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;'))
a.conststring(1,'S13SquareFix v9: original tab click');a.invoke(0x71,[1],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.mark('done');a.ret()
code[(P,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(16,2,3,a.resultwords())

# Generate DEX image in canonical sorted sections.
parts=bytearray(b'\0'*0x70)
def align(n=4):
 while len(parts)%n:parts.append(0)
def append(b,alignby=None):
 if alignby:align(alignby)
 off=len(parts);parts.extend(b);return off
strings_off=append(bytes(4*len(strings)),4)
types_off=append(bytes(4*len(types)),4)
protos_off=append(bytes(12*len(protos)),4)
fields_off=append(bytes(8*len(fields)),4)
methods_off=append(bytes(8*len(methods)),4)
class_defs_off=append(bytes(32*len(classes)),4)
data_off=len(parts)
# shared type_list objects: classes interfaces and prototype parameter lists
typelists=[]
for ret,args in protos:
 if args and args not in typelists:typelists.append(args)
for cl,supercl,interfaces in classes:
 if interfaces and tuple(interfaces) not in typelists:typelists.append(tuple(interfaces))
typelist_offsets={}
for li in typelists:
 off=append(put32(len(li))+b''.join(put16(tid[t]) for t in li)+(b'\0\0' if len(li)%2 else b''),4)
 typelist_offsets[li]=off
# String data
string_data_off=len(parts)
string_offsets=[]
for s in strings:
 # all ASCII; uleb length in UTF-16 and utf8 bytes
 b=s.encode('utf-8');string_offsets.append(append(ULEB(len(s))+b+b'\0'))
# code_item
code_offsets={}
for cls,superclass,ifaces in classes:
 for m in methods:
  if m[0]!=cls or m not in code:continue
  regs,ins,outs,insns=code[m]
  assert len(insns)%2==0
  c_off=append(struct.pack('<HHHHII',regs,ins,outs,0,0,len(insns)//2)+insns,4)
  code_offsets[m]=c_off
# class_data; direct methods sorted by methodidx then virtual sorted
class_data_offsets={}
for cls,superclass,ifaces in classes:
 direct=[m for m in methods if m[0]==cls and m[1]=='<init>']
 virtual=[m for m in methods if m[0]==cls and m[1]!='<init>']
 def encmethods(methods,flags):
  out=bytearray();last=0
  for m in methods:
   idx=mid[m];out+=ULEB(idx-last);out+=ULEB(flags);out+=ULEB(code_offsets[m]);last=idx
  return out
 classdata=ULEB(0)+ULEB(0)+ULEB(len(direct))+ULEB(len(virtual))+encmethods(direct,0x10001)+encmethods(virtual,0x1 if cls==H else 0x4)
 class_data_offsets[cls]=append(classdata)
# map_list
mapoff=len(parts); align(4);mapoff=len(parts)
mapitems=[(0x0000,1,0),(0x0001,len(strings),strings_off),(0x0002,len(types),types_off),(0x0003,len(protos),protos_off),(0x0004,len(fields),fields_off),(0x0005,len(methods),methods_off),(0x0006,len(classes),class_defs_off)]
if typelist_offsets:mapitems.append((0x1001,len(typelist_offsets),min(typelist_offsets.values())))
mapitems.extend([(0x2002,len(strings),string_data_off),(0x2001,len(code_offsets),min(code_offsets.values())),(0x2000,len(classes),min(class_data_offsets.values()))])
mapitems.append((0x1000,1,mapoff));mapitems.sort(key=lambda x:x[2]);append(put32(len(mapitems))+b''.join(struct.pack('<HHII',ty,0,num,off) for ty,num,off in mapitems))
# Fill indexed sections
for i,off in enumerate(string_offsets): struct.pack_into('<I',parts,strings_off+i*4,off)
for i,t in enumerate(types):struct.pack_into('<I',parts,types_off+i*4,sid[t])
for i,(ret,args) in enumerate(protos):struct.pack_into('<III',parts,protos_off+i*12,sid[shorty(ret)+''.join(map(shorty,args))],tid[ret],typelist_offsets.get(args,0))
for i,(owner,name,typ) in enumerate(fields):struct.pack_into('<HHI',parts,fields_off+i*8,tid[owner],tid[typ],sid[name])
for i,(owner,name,proto) in enumerate(methods):struct.pack_into('<HHI',parts,methods_off+i*8,tid[owner],pid[parseproto(proto)],sid[name])
for i,(cls,sup,ifaces) in enumerate(classes):
 src='Hook.java' if cls==H else ('NavProbe.java' if cls==P else 'Touch.java'); acc=0x1 if cls==H else 0x1
 struct.pack_into('<IIIIIIII',parts,class_defs_off+i*32,tid[cls],acc,tid[sup],typelist_offsets.get(tuple(ifaces),0),sid[src],0,class_data_offsets[cls],0)
# header
parts[:8]=b'dex\n035\0'
struct.pack_into('<I',parts,0x20,len(parts))
struct.pack_into('<I',parts,0x24,0x70)
struct.pack_into('<I',parts,0x28,0x12345678)
struct.pack_into('<I',parts,0x34,mapoff)
struct.pack_into('<IIIIIIIIIIII',parts,0x38,len(strings),strings_off,len(types),types_off,len(protos),protos_off,len(fields),fields_off,len(methods),methods_off,len(classes),class_defs_off)
struct.pack_into('<II',parts,0x68,len(parts)-data_off,data_off)
parts[12:32]=hashlib.sha1(parts[32:]).digest()
struct.pack_into('<I',parts,8,zlib.adler32(parts[12:])&0xffffffff)
(B/'classes.dex').write_bytes(parts)
print('DEX size',len(parts),'ids',len(strings),len(types),len(protos),len(fields),len(methods),'code',len(code))

# Patch resource-less existing binary manifest with equal-length strings.
with zipfile.ZipFile(apkbase) as z: manifest=bytearray(z.read('AndroidManifest.xml'))
assert len(PKG)==len('com.s13.youtubefullscreenfix')
orig='com.s13.youtubefullscreenfix'.encode('utf-16le');new=PKG.encode('utf-16le');assert manifest.count(orig)==1;manifest=manifest.replace(orig,new)
orig='S13 YouTube Fullscreen Fix'.encode('utf-16le');new='S13 YouTube Squaremode Fix'.encode('utf-16le');assert len(orig)==len(new) and manifest.count(orig)==1;manifest=manifest.replace(orig,new)
assert manifest.count('1.6'.encode('utf-16le'))==1
manifest=manifest.replace('1.6'.encode('utf-16le'),'1.9'.encode('utf-16le'))
orig='Forces stock YouTube fullscreen player to fill the S13 display.'.encode('utf-16le')
# ensure equal-length description
s='Restores bottom YouTube tab clicks in S13 square screen mode.'
s=s.ljust(len(orig)//2,'.');assert len(s)==63
assert manifest.count(orig)==1;manifest=manifest.replace(orig,s.encode('utf-16le'))
# APK build minimal resources as original, new classes.dex and xposed_init
unsigned=B/'S13-YouTube-SquareMode-PoC-unsigned.apk'
with zipfile.ZipFile(apkbase) as z: res=z.read('resources.arsc')
with zipfile.ZipFile(unsigned,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.writestr('AndroidManifest.xml',manifest)
 z.writestr('resources.arsc',res)
 z.writestr('classes.dex',parts)
 z.writestr('assets/xposed_init', 'com.s13.youtubesquaremodefix.Hook\n')
print('Unsigned APK',unsigned.stat().st_size)
# create signing key; local test-only, do not reuse user's original signing identity.
ks=B/'debug-keystore.p12'
if not ks.exists():subprocess.run(['keytool','-genkeypair','-alias','testsign','-keyalg','RSA','-keysize','2048','-validity','1000','-keystore',str(ks),'-storetype','PKCS12','-storepass','s13testfix','-keypass','s13testfix','-dname','CN=S13 Test Module,O=Experimental,C=US'],check=True,stdout=subprocess.DEVNULL)
signed=B/'S13-YouTube-SquareMode-PoC.apk';signed.write_bytes(unsigned.read_bytes())
subprocess.run(['jarsigner','-keystore',str(ks),'-storepass','s13testfix','-keypass','s13testfix','-sigalg','SHA256withRSA','-digestalg','SHA-256',str(signed),'testsign'],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['jarsigner','-verify',str(signed)],check=True,stdout=subprocess.DEVNULL)
print('SIGNED APK',signed,signed.stat().st_size)
