S13 YouTube Square Mode Tab Fix v9 - reduced hook scope (EXPERIMENTAL)
Package: com.s13.youtubesquaremodefix, LSPosed YouTube-only scope. VersionName 1.9.
Compared to working tabs / broken video v8, no longer hooks global android.view.View.performClick().
Only hooks YouTube MainActivity.dispatchTouchEvent. Square mode only: checks that DOWN and UP
land on same bottom tab within 650 ms, then calls that tab's existing performClick.
Leaves fullscreen module unchanged. No display, layout or scaling modifications.
Important: does NOT suppress possible duplicate native clicks, as square mode native tab clicks were broken
in testing. Test BOTH fullscreen playback and tab navigation with v9 enabled.
If fullscreen still regresses: disable v9 in LSPosed and reboot.
Do not use v7 or v8 if they break fullscreen.
