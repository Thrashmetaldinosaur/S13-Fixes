#!/usr/bin/env python3
"""Repack APK with 4-byte aligned uncompressed resources.arsc, V1+V2 signing."""
from pathlib import Path
import struct,zipfile,subprocess,hashlib,io
from cryptography.hazmat.primitives.serialization import pkcs12,Encoding,PublicFormat
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes

ROOT=Path('/mnt/data')
SRC=ROOT/'s13-queue-rescue-v1/S13-YouTube-Queue-Fit-v1-v1signed.apk'
KEY=ROOT/'s13-queue-rescue-v1/debug-keystore.p12'
INTER=ROOT/'s13-queue-rescue-v1'
OUTPUT=ROOT/'S13-YouTube-Queue-Fit-v1-TEST.apk'

with KEY.open('rb') as f:
 priv,cert,additional=pkcs12.load_key_and_certificates(f.read(),b's13testfix')
assert priv and cert

def u32(n):return struct.pack('<I',n)
def u64(n):return struct.pack('<Q',n)
def lp(v):return u32(len(v))+v

# V1-signed input: rewriting local headers doesn't alter signatures, which cover individual archive entry contents.
with zipfile.ZipFile(SRC) as z:
 entries={i.filename:z.read(i.filename) for i in z.infolist()}
assert 'resources.arsc' in entries
pre=INTER/'repacked-v1.apk'
with zipfile.ZipFile(pre,'w') as z:
 # First entry's contents naturally begin at 30 + len('resources.arsc') = 44, divisible by 4.
 z.writestr('resources.arsc',entries['resources.arsc'],compress_type=zipfile.ZIP_STORED)
 for name,val in entries.items():
  if name != 'resources.arsc':
   z.writestr(name,val,compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(pre) as z:
 info=z.getinfo('resources.arsc');offset=info.header_offset+30+len(info.filename.encode())+len(info.extra)
 assert info.compress_type == 0 and offset%4 == 0,(info.compress_type,offset)
 assert z.testzip() is None
subprocess.run(['jarsigner','-verify',str(pre)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)

SIGNER_ALG=0x0103 # RSASSA-PKCS1-v1_5 with SHA-256

# APK v2 uses SHA-256 1MiB chunked content digest over ZIP entries, central dir and patched EOCD.
def chunked_sha256(chunks):
 chunk_hashes=[]
 for section in chunks:
  for off in range(0,len(section),1024*1024):
   part=section[off:off+1024*1024]
   chunk_hashes.append(hashlib.sha256(b'\xa5'+u32(len(part))+part).digest())
 return hashlib.sha256(b'\x5a'+u32(len(chunk_hashes))+b''.join(chunk_hashes)).digest()

def eocd_info(data):
 for n in range(len(data)-22,max(-1,len(data)-22-65535),-1):
  if data[n:n+4]==b'PK\x05\x06':
   comment_length=struct.unpack_from('<H',data,n+20)[0]
   if n+22+comment_length==len(data):
    return n,struct.unpack_from('<I',data,n+16)[0]
 raise AssertionError('EOCD not found')

binary=pre.read_bytes();eocd,cd=eocd_info(binary)
assert cd<eocd
signed_eocd=bytearray(binary[eocd:]);struct.pack_into('<I',signed_eocd,16,cd)
digest=chunked_sha256([binary[:cd],binary[cd:eocd],bytes(signed_eocd)])

sig_record=u32(SIGNER_ALG)+lp(priv.sign(lp(u32(SIGNER_ALG)+lp(digest))+lp(lp(cert.public_bytes(Encoding.DER)))+lp(b''),padding.PKCS1v15(),hashes.SHA256()))
# exactly one signer, one content digest algorithm, and one public certificate
signed_data=lp(lp(u32(SIGNER_ALG)+lp(digest)))+lp(lp(cert.public_bytes(Encoding.DER)))+lp(b'')
signature=priv.sign(signed_data,padding.PKCS1v15(),hashes.SHA256())
public=cert.public_key().public_bytes(Encoding.DER,PublicFormat.SubjectPublicKeyInfo)
signer=lp(signed_data)+lp(lp(u32(SIGNER_ALG)+lp(signature)))+lp(public)
scheme_block=lp(lp(signer))
# LP64 pair: length includes 4 byte pair id plus block data
pair=u64(4+len(scheme_block))+u32(0x7109871a)+scheme_block
size=len(pair)+24
apk_sig_block=u64(size)+pair+u64(size)+b'APK Sig Block 42'
assert len(apk_sig_block)==size+8
updated_eocd=bytearray(binary[eocd:])
struct.pack_into('<I',updated_eocd,16,cd+len(apk_sig_block))
OUTPUT.write_bytes(binary[:cd]+apk_sig_block+binary[cd:eocd]+updated_eocd)

# Validate signing block, signed contents, and the corrected Android ZIP layout.
with zipfile.ZipFile(OUTPUT) as z:
 assert z.testzip() is None
 info=z.getinfo('resources.arsc')
 off=info.header_offset+30+len(info.filename.encode())+len(info.extra)
 assert info.compress_type==0 and off%4==0
 assert z.read('resources.arsc')==entries['resources.arsc']
 check=z.read('classes.dex')
 assert check==entries['classes.dex']
assert b'APK Sig Block 42' in OUTPUT.read_bytes()
newbytes=OUTPUT.read_bytes()
new_eocd,new_cd=eocd_info(newbytes)
assert new_cd==cd+len(apk_sig_block) and new_eocd==eocd+len(apk_sig_block)
# Independently recompute signed digest from NEW bytes with EOCD's CD offset patched back to signing block start.
check_eocd=bytearray(newbytes[new_eocd:]);struct.pack_into('<I',check_eocd,16,cd)
computed=chunked_sha256([newbytes[:cd],newbytes[new_cd:new_eocd],bytes(check_eocd)])
assert computed==digest
cert.public_key().verify(signature,signed_data,padding.PKCS1v15(),hashes.SHA256())
subprocess.run(['jarsigner','-verify',str(OUTPUT)],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
print('PASS: ZIP entries verified')
print('PASS: resources.arsc STORED and 4-byte aligned at local offset',off)
print('PASS: V1 JAR signature verified')
print('PASS: V2 RSA SHA256 signature and independent content digest verified')
print('PASS: DEX unchanged and APK Signing Block location verified')
print('OUTPUT:',OUTPUT,OUTPUT.stat().st_size,'bytes')
print('SHA256:',hashlib.sha256(OUTPUT.read_bytes()).hexdigest())
