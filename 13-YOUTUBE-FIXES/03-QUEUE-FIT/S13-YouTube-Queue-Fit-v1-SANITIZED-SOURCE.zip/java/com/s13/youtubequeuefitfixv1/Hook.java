package com.s13.youtubequeuefitfixv1;

import android.view.View;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Readable Java equivalent of the DEX entry point. */
public final class Hook implements IXposedHookLoadPackage {
    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.google.android.youtube".equals(lp.packageName)) return;
        XposedHelpers.findAndHookMethod(View.class, "setTranslationY", float.class, new Rescue());
        XposedBridge.log("S13QueueRescue v1: hook installed");
    }
}
