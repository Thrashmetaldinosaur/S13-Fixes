package com.s13.youtubequeuefitfixv1;

import android.content.res.Resources;
import android.view.View;
import android.view.ViewParent;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

/** Readable Java equivalent of the queue-fit hook in the experimental DEX. */
public final class Rescue extends XC_MethodHook {
    @Override protected void afterHookedMethod(MethodHookParam param) {
        View layer = (View)param.thisObject;
        ViewParent maybeParent = layer.getParent();
        if (!(maybeParent instanceof View)) return;
        View parent = (View)maybeParent;
        int pw = parent.getWidth(), ph = parent.getHeight();
        if (pw < 430 || ph < 430) return;
        int lw = layer.getWidth(), lh = layer.getHeight();
        if (lw < 60 || lh < 60) return;
        Resources r = parent.getResources();
        int playerId = r.getIdentifier("player_view", "id", "com.google.android.youtube");
        if (playerId == 0 || parent.getId() != playerId) return;
        // Scale uniformly, preserving video aspect ratio.
        float factor = Math.min((float)pw / lw, (float)ph / lh);
        if (factor <= 1.07f || factor >= 2.5f) return;
        layer.setScaleX(factor);
        layer.setScaleY(factor);
        layer.invalidate();
        XposedBridge.log("S13QueueRescue v1: layer=" + lw + "x" + lh + " scale=" + factor);
    }
}
