import zipfile,struct,hashlib,zlib
from pathlib import Path
p=Path('/mnt/data/S13-YouTube-Queue-Fit-v1-TEST.apk')
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None
    b=z.read('classes.dex');ini=z.read('assets/xposed_init').decode()
    assert ini=='com.s13.youtubequeuefitfixv1.Hook\n'
    assert hashlib.sha1(b[32:]).digest()==b[12:32]
    assert zlib.adler32(b[12:])&0xffffffff==struct.unpack_from('<I',b,8)[0]
    pkg=z.read('AndroidManifest.xml')
    assert 'com.s13.youtubequeuefitfixv1'.encode('utf-16le') in pkg
    assert 'S13 YouTube Queue Fit Tool'.encode('utf-16le') in pkg
    info=z.getinfo('resources.arsc')
    assert info.compress_type==0
    assert (info.header_offset+30+len(info.filename.encode())+len(info.extra))%4==0
# read DEX tables
u16=lambda o:struct.unpack_from('<H',b,o)[0]
u32=lambda o:struct.unpack_from('<I',b,o)[0]
def uleb(o):
    n=0;shift=0
    while 1:
        bb=b[o];o+=1;n|=(bb&0x7f)<<shift
        if not bb&0x80:return n,o
        shift+=7
def getstr(i):
    o=u32(u32(0x3c)+i*4)
    _,o=uleb(o)
    return b[o:b.index(b'\0',o)].decode()
types=[getstr(u32(u32(0x44)+i*4)) for i in range(u32(0x40))]
methods=[]
for i in range(u32(0x58)):
    off=u32(0x5c)+i*8
    idx=u16(off);ni=u32(off+4)
    methods.append((types[idx],getstr(ni)))
codeoffs={}
for i in range(u32(0x60)):
    off=u32(0x64)+i*32; cd=u32(off+24)
    if not cd:continue
    staticfields,cd=uleb(cd);instancefields,cd=uleb(cd);direct,cd=uleb(cd);virtual,cd=uleb(cd)
    last=0
    for _ in range(staticfields+instancefields):
        _,cd=uleb(cd);_,cd=uleb(cd)
    for count in (direct,virtual):
        last=0
        for _ in range(count):
            delta,cd=uleb(cd);last+=delta
            flags,cd=uleb(cd);codeoff,cd=uleb(cd)
            codeoffs[methods[last]]=codeoff
expected={'handleLoadPackage','afterHookedMethod','<init>'}
assert set(k[1] for k in codeoffs)==expected,codeoffs
width={0x0:1,0x0e:1,0x12:1,0x13:2,0x14:3,0x1a:2,0x1c:2,0x1f:2,0x20:2,0x22:2,0x23:2,
        0x4d:2,0x54:2,0x62:2,0x6e:3,0x70:3,0x71:3,0x0a:1,0x0c:1,0x2d:2,0x2e:2,0x82:1,0xa9:2,
        0x38:2,0x39:2,0x33:2,0x34:2,0x3b:2,0x3d:2}
for (owner,name),off in codeoffs.items():
    regs,ins,outs,tries,debug,sz=struct.unpack_from('<HHHHII',b,off)
    words=list(struct.unpack_from('<'+'H'*sz,b,off+16))
    pc=0;boundaries=set();branches=[]
    while pc<sz:
        boundaries.add(pc)
        op=words[pc]&255
        w=width.get(op)
        assert w,(owner,name,'bad opcode',hex(op),pc)
        if 0x32<=op<=0x3d:
            assert pc+1<sz
            delta=struct.unpack('<h',struct.pack('<H',words[pc+1]))[0]
            branches.append(pc+delta)
        pc+=w
    assert pc==sz
    assert all(t in boundaries for t in branches),(name,'wrong branch targets',[t for t in branches if t not in boundaries])
    print('PASS CODE',owner.split('/')[-1],name,'regs',regs,'ins',ins,'codeunits',sz,'branches',len(branches))
print('PASS APK DEX and bytecode integrity / branch targets')
print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
