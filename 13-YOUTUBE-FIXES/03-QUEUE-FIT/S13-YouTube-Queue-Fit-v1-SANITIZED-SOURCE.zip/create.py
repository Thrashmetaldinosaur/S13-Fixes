#!/usr/bin/env python3
"""Build a reversible third LSPosed module correcting fitted video layer size in YouTube queue playback.
No changes to the original S13 v1.6 fullscreen module or v9 square navigation module.
"""
from pathlib import Path
import zipfile, textwrap, struct, hashlib, zlib, subprocess
B=Path(__file__).parent
APKBASE=Path('/mnt/data/S13-YouTube-Fullscreen-Fix-Original.apk')
PREV=Path('/mnt/data/S13-YouTube-SquareMode-TabFix-v9-Source.zip')
with zipfile.ZipFile(PREV) as z:
    donor=z.read('build.py').decode()
core=donor[donor.index('def shorty(t):'):donor.index('code={}')]
tail=donor[donor.index('# Generate DEX image in canonical sorted sections.'):donor.index('# Patch resource-less existing binary manifest')]
# exact equal-length strings to preserve Android compiled manifest offsets
OLDPKG='com.s13.youtubefullscreenfix'
PKG='com.s13.youtubequeuefitfixv1'
assert len(OLDPKG)==len(PKG),(len(OLDPKG),len(PKG))
H='L'+PKG.replace('.','/')+'/Hook;'
T='L'+PKG.replace('.','/')+'/Rescue;'
fields=[('Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;','packageName','Ljava/lang/String;'),('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'),('Ljava/lang/Float;','TYPE','Ljava/lang/Class;')]
methods=[
 ('Ljava/lang/Object;','<init>','()V'),
 ('Lde/robv/android/xposed/XC_MethodHook;','<init>','()V'),
 (H,'<init>','()V'),(H,'handleLoadPackage','(Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;)V'),
 (T,'<init>','()V'),(T,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V'),
 ('Ljava/lang/String;','equals','(Ljava/lang/Object;)Z'),
 ('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'),
 ('Lde/robv/android/xposed/XposedHelpers;','findAndHookMethod','(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;'),
 ('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'),
 ('Landroid/view/View;','getWidth','()I'),
 ('Landroid/view/View;','getHeight','()I'),
 ('Landroid/view/View;','getId','()I'),
 ('Landroid/view/View;','getResources','()Landroid/content/res/Resources;'),
 ('Landroid/content/res/Resources;','getIdentifier','(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I'),
 ('Landroid/view/View;','setScaleX','(F)V'),
 ('Landroid/view/View;','setScaleY','(F)V'),
 ('Landroid/view/View;','invalidate','()V'),
 ('Ljava/lang/Math;','min','(FF)F'),
 ('Ljava/lang/StringBuilder;','<init>','()V'),
 ('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'),
 ('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'),
 ]
classes=[(H,'Ljava/lang/Object;',['Lde/robv/android/xposed/IXposedHookLoadPackage;']),(T,'Lde/robv/android/xposed/XC_MethodHook;',[])]
# common string sorting and dex structures from known-working v9 builder
pre=donor[donor.index('def shorty(t):'):donor.index('code={}')]
# remove internals up to 'textstrings=' for our own string set
pre_a=pre[:pre.index('textstrings=')]
pre_b=pre[pre.index('for m in methods:'):]
# Build vars in local scope for exec; sorted lists dictionary etc
src='''import struct, hashlib, zlib, zipfile
'''+pre_a+'''textstrings={
 'com.google.android.youtube','setTranslationY','S13QueueRescue v1: hook installed',
 'S13QueueRescue v1: layer=', 'x', ' scale=',
 'player_view','id','Hook.java','Rescue.java'
}
'''+pre_b
exec(src,globals())
# Note original generator sets classes in a sorted order and sorts fields/methods for canonical DEX
code={}
a=ASM();a.invoke(0x70,[0],('Ljava/lang/Object;','<init>','()V'));a.ret()
code[(H,'<init>','()V')]=(1,1,1,a.resultwords())
# H.handleLoadPackage (this=v5, pkg param=v6)
a=ASM()
a.conststring(0,'com.google.android.youtube')
a.iget(1,6,('Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;','packageName','Ljava/lang/String;'))
a.invoke(0x6e,[0,1],('Ljava/lang/String;','equals','(Ljava/lang/Object;)Z'));a.result(1)
a.branchz(0x39,1,'install');a.ret()
a.mark('install')
a.constclass(0,'Landroid/view/View;');a.conststring(1,'setTranslationY')
a.emit(0x62 | (2 << 8),fid[('Ljava/lang/Float;','TYPE','Ljava/lang/Class;')]) # sget-object v2,Float.TYPE
a.newinstance(3,T);a.invoke(0x70,[3],(T,'<init>','()V'))
a.const4(4,2);a.newarray(4,4,'[Ljava/lang/Object;')
a.const4(5,0);a.aget(0x4d,2,4,5) # aput-object v2,v4,v5
a.const4(5,1);a.aget(0x4d,3,4,5) # aput-object v3,v4,v5
a.invoke(0x71,[0,1,4],('Lde/robv/android/xposed/XposedHelpers;','findAndHookMethod','(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Object;)Lde/robv/android/xposed/XC_MethodHook$Unhook;'))
a.conststring(0,'S13QueueRescue v1: hook installed');a.invoke(0x71,[0],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.ret()
code[(H,'handleLoadPackage','(Lde/robv/android/xposed/callbacks/XC_LoadPackage$LoadPackageParam;)V')]=(7,2,4,a.resultwords())
# T.<init>
a=ASM();a.invoke(0x70,[0],('Lde/robv/android/xposed/XC_MethodHook;','<init>','()V'));a.ret()
code[(T,'<init>','()V')]=(1,1,1,a.resultwords())
# T.afterHookedMethod(): v14=this, v15=param, v0..v13 locals
# Only touches YouTube's root video-layer view, the direct child of its full-size player_view.
a=ASM()
a.iget(0,15,('Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;','thisObject','Ljava/lang/Object;'))
a.checkcast(0,'Landroid/view/View;')
a.invoke(0x6e,[0],('Landroid/view/View;','getParent','()Landroid/view/ViewParent;'));a.result(1,True)
a.instance_of(2,1,'Landroid/view/View;');a.branchz(0x38,2,'done')
a.checkcast(1,'Landroid/view/View;')
# Parent must be fullscreen 466x466-ish YouTube player, not inline player or controls.
a.invoke(0x6e,[1],('Landroid/view/View;','getWidth','()I'));a.result(4)
a.invoke(0x6e,[1],('Landroid/view/View;','getHeight','()I'));a.result(5)
a.const16(3,430);a.branch(0x34,4,3,'done');a.branch(0x34,5,3,'done')
a.invoke(0x6e,[0],('Landroid/view/View;','getWidth','()I'));a.result(6)
a.invoke(0x6e,[0],('Landroid/view/View;','getHeight','()I'));a.result(7)
a.const16(3,60);a.branch(0x34,6,3,'done');a.branch(0x34,7,3,'done')
# Verify parent resource id player_view (the same object v1.6 uses for video-layer centering).
a.invoke(0x6e,[1],('Landroid/view/View;','getResources','()Landroid/content/res/Resources;'));a.result(9,True)
a.conststring(2,'player_view');a.conststring(3,'id');a.conststring(8,'com.google.android.youtube')
a.invoke(0x6e,[9,2,3,8],('Landroid/content/res/Resources;','getIdentifier','(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I'));a.result(2)
a.branchz(0x38,2,'done')
a.invoke(0x6e,[1],('Landroid/view/View;','getId','()I'));a.result(8)
a.branch(0x33,2,8,'done')
# Fit, no cropping: s=min(playerW/layerW, playerH/layerH). This scales only undersized layers.
a.emit(0x82 | (10<<8) | (4<<12))  # int-to-float v10,v4
a.emit(0x82 | (11<<8) | (6<<12))  # int-to-float v11,v6
a.emit(0xa9 | (10<<8),10 | (11<<8)) # div-float v10,v10,v11
a.emit(0x82 | (11<<8) | (5<<12))  # int-to-float v11,v5
a.emit(0x82 | (12<<8) | (7<<12))  # int-to-float v12,v7
a.emit(0xa9 | (11<<8),11 | (12<<8)) # div-float v11,v11,v12
a.invoke(0x71,[10,11],('Ljava/lang/Math;','min','(FF)F'));a.result(12)
a.const32(13,struct.unpack('<I',struct.pack('<f',1.07))[0])
a.emit(0x2e | (8<<8), 12 | (13<<8)) # cmpg-float v8,v12,v13
a.branchz(0x3d,8,'done') # if <=1.07, skip
a.const32(13,struct.unpack('<I',struct.pack('<f',2.5))[0])
a.emit(0x2d | (8<<8),12 | (13<<8)) # cmpl-float v8,v12,v13
a.branchz(0x3b,8,'done') # if >=2.5, skip
# v1.6 has just set translations. Scale the *video layer* uniformly around its center.
a.invoke(0x6e,[0,12],('Landroid/view/View;','setScaleX','(F)V'))
a.invoke(0x6e,[0,12],('Landroid/view/View;','setScaleY','(F)V'))
a.invoke(0x6e,[0],('Landroid/view/View;','invalidate','()V'))
# concise diagnostic log
a.newinstance(2,'Ljava/lang/StringBuilder;');a.invoke(0x70,[2],('Ljava/lang/StringBuilder;','<init>','()V'))
a.conststring(3,'S13QueueRescue v1: layer=');a.invoke(0x6e,[2,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[2,6],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,'x');a.invoke(0x6e,[2,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[2,7],('Ljava/lang/StringBuilder;','append','(I)Ljava/lang/StringBuilder;'))
a.conststring(3,' scale=');a.invoke(0x6e,[2,3],('Ljava/lang/StringBuilder;','append','(Ljava/lang/String;)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[2,12],('Ljava/lang/StringBuilder;','append','(F)Ljava/lang/StringBuilder;'))
a.invoke(0x6e,[2],('Ljava/lang/StringBuilder;','toString','()Ljava/lang/String;'));a.result(2,True)
a.invoke(0x71,[2],('Lde/robv/android/xposed/XposedBridge;','log','(Ljava/lang/String;)V'))
a.mark('done');a.ret()
code[(T,'afterHookedMethod','(Lde/robv/android/xposed/XC_MethodHook$MethodHookParam;)V')]=(16,2,4,a.resultwords())
# Complete the DEX via the known-working v9 assembly routines.
exec(tail.replace("src='Hook.java' if cls==H else ('NavProbe.java' if cls==P else 'Touch.java')","src='Hook.java' if cls==H else 'Rescue.java'").replace("acc=0x1 if cls==H else 0x1","acc=0x1"),globals())
# Make APK with unique package, preserving 1.6 data and Xposed metadata.
with zipfile.ZipFile(APKBASE) as z:
    manifest=bytearray(z.read('AndroidManifest.xml'));res=z.read('resources.arsc')
def same_utf16(old,new):
    global manifest
    assert len(old)==len(new),(old,new,len(old),len(new))
    ob=old.encode('utf-16le');nb=new.encode('utf-16le')
    assert manifest.count(ob)==1,(old,manifest.count(ob))
    manifest=manifest.replace(ob,nb)
same_utf16(OLDPKG,PKG)
same_utf16('S13 YouTube Fullscreen Fix','S13 YouTube Queue Fit Tool')
same_utf16('1.6','1.0')
orig='Forces stock YouTube fullscreen player to fill the S13 display.'
new='Fits videos after the YouTube queue changes the player size.'
same_utf16(orig,new.ljust(len(orig),'.'))
unsigned=B/'S13-YouTube-Queue-Fit-unsigned.apk'
with zipfile.ZipFile(unsigned,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr('AndroidManifest.xml',manifest)
    z.writestr('resources.arsc',res)
    z.writestr('classes.dex',parts)
    z.writestr('assets/xposed_init',PKG+'.Hook\n')
ks=B/'debug-keystore.p12'
if not ks.exists():
    subprocess.run(['keytool','-genkeypair','-alias','testsign','-keyalg','RSA','-keysize','2048','-validity','1000','-keystore',str(ks),'-storetype','PKCS12','-storepass','s13testfix','-keypass','s13testfix','-dname','CN=S13 Queue Test Module,O=Experimental,C=US'],check=True,stdout=subprocess.DEVNULL)
signed=B/'S13-YouTube-Queue-Fit-v1-v1signed.apk';signed.write_bytes(unsigned.read_bytes())
subprocess.run(['jarsigner','-keystore',str(ks),'-storepass','s13testfix','-keypass','s13testfix','-sigalg','SHA256withRSA','-digestalg','SHA-256',str(signed),'testsign'],check=True,stdout=subprocess.PIPE)
subprocess.run(['jarsigner','-verify',str(signed)],check=True,stdout=subprocess.PIPE)
print('SIGNABLE INPUT',signed,signed.stat().st_size)
