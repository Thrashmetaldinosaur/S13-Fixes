S13 YouTube Queue Fit - experimental companion module v1.0

ORIGINALS ARE UNCHANGED:
- S13 YouTube Fullscreen Fix v1.6 (com.s13.youtubefullscreenfix)
- S13 YouTube Square Mode Tab Fix v9 (com.s13.youtubesquaremodefix)

Why a separate companion?
The uploaded GOLDEN 7z APK is byte-for-byte identical to the installed
Fullscreen Fix v1.6 and includes its full Java source, but not the original
APK signing private key. Android will not permit a different-signed APK
to update the original package in place. This test companion avoids any
uninstall or risk to the working fullscreen fix.

Hypothesis:
In fullscreen, the original module centers YouTube's fitted video layer,
then sets its scale to 1.0. This leaves queue-resized layers like 294x221
small inside a 466x466 player. The companion hooks View.setTranslationY
within YouTube only. When the directly parented player_view child is undersized,
it adds a uniform scale = min(playerW/layerW, playerH/layerH), preserving ratio.
Normally fitted 466x280 or 466x350 layers receive no correction.

THIS APK IS AN UNTESTED EXPERIMENT, NOT A VERIFIED FIX.
The module's safeguards are geometry-based, not queue-state-based.
It can affect any similarly undersized fullscreen video layer.

Install:
- ADB install APK, enable module under LSPosed, scope only YouTube,
  keep the two other YouTube modules enabled and reboot.
- Test queued playback, standalone playback, square mode tabs, fullscreen controls.
- Inspect LSPosed log for S13QueueRescue and VerifyError messages.
Rollback:
- Disable only 'S13 YouTube Queue Fit Tool' in LSPosed and reboot.

Readable Java equivalent is in java/; create.py is the DEX/APK builder,
sign.py builds the V2-signed Android 13 package, validate.py checks the DEX
checksums and all branch targets. The original APK and donor v9 source ZIP
were used as local resources by create.py and are not bundled here.

The private test signing key is not included in this source archive.
