package com.s13.twistglance;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/** Cosmetic glance layer, not an authentication/security lock screen. */
final class GlanceController {
    private static final long GLANCE_MS = 4000L;
    private final Context context;
    private final PowerManager power;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final WindowManager windows;
    private View overlay;
    private Runnable timeout;

    GlanceController(Context ctx, PowerManager power) {
        this.context = ctx;
        this.power = power;
        this.windows = (WindowManager) ctx.getSystemService(Context.WINDOW_SERVICE);
    }

    void showOnMainThread() { main.post(this::show); }

    private void show() {
        if (overlay != null || windows == null) return;
        try {
            // Overlay is added FROM WIITE process; this checks the HOST app's AppOp.
            // A separate module permission alone cannot grant WIITE overlay access.
            if (!Settings.canDrawOverlays(context)) {
                XposedBridge.log("S13GlanceV5: host overlay access unavailable; v4-style wake retained");
                return;
            }
            LinearLayout panel = new LinearLayout(context);
            panel.setGravity(Gravity.CENTER);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setBackgroundColor(Color.BLACK);

            TextClock time = new TextClock(context);
            time.setFormat12Hour("h:mm");
            time.setFormat24Hour("HH:mm");
            time.setTextColor(Color.WHITE);
            time.setTextSize(56f);
            time.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            time.setGravity(Gravity.CENTER);
            panel.addView(time);

            TextClock date = new TextClock(context);
            date.setFormat12Hour("EEE, MMM d");
            date.setFormat24Hour("EEE, MMM d");
            date.setTextColor(0xffaeb6c2);
            date.setTextSize(15f);
            date.setGravity(Gravity.CENTER);
            panel.addView(date);

            TextView hint = new TextView(context);
            hint.setText("TAP TO OPEN");
            hint.setTextColor(0xff9299a3);
            hint.setTextSize(11f);
            hint.setGravity(Gravity.CENTER);
            hint.setPadding(0, 22, 0, 0);
            panel.addView(hint);

            panel.setClickable(true);
            panel.setOnClickListener(v -> {
                dismiss();
                XposedBridge.log("S13GlanceV5: single tap -> normal watch");
            });
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.OPAQUE);
            params.gravity = Gravity.CENTER;
            params.setTitle("S13 Glance v5");
            windows.addView(panel, params);
            overlay = panel;
            timeout = () -> {
                // Only our own, still-visible glance view may force an early screen-off.
                if (overlay != panel) return;
                dismiss();
                try {
                    if (power != null && power.isInteractive()) {
                        XposedHelpers.callMethod(power, "goToSleep", SystemClock.uptimeMillis());
                        XposedBridge.log("S13GlanceV5: four-second sleep requested");
                    }
                } catch (Throwable t) {
                    XposedBridge.log("S13GlanceV5: sleep rejected by firmware; normal timeout retained");
                    XposedBridge.log(t);
                }
            };
            main.postDelayed(timeout, GLANCE_MS);
            XposedBridge.log("S13GlanceV5: overlay displayed; 4-second timer armed");
        } catch (Throwable t) {
            XposedBridge.log("S13GlanceV5: overlay failed; v4-style wake retained");
            XposedBridge.log(t);
            dismiss();
        }
    }

    private void dismiss() {
        if (timeout != null) main.removeCallbacks(timeout);
        timeout = null;
        View prior = overlay;
        overlay = null;
        if (prior != null) {
            try { windows.removeViewImmediate(prior); }
            catch (Throwable t) { XposedBridge.log(t); }
        }
    }
}
