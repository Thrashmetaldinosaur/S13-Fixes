package com.s13.twistglance;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.PowerManager;
import android.os.SystemClock;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

final class WakeEngine implements SensorEventListener {
    private static boolean registered = false;
    private static long lastWake = 0L;
    private static final long COOLDOWN_MS = 5000L; // Preserve v4's known-good cooldown.
    private final PowerManager power;
    private final GlanceController glance;

    private WakeEngine(Context ctx) {
        power = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
        glance = new GlanceController(ctx, power);
    }

    static synchronized void install(Context ctx) {
        if (registered) return;
        SensorManager sensors = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        if (sensors == null) { XposedBridge.log("S13GlanceV5: no SensorManager"); return; }
        Sensor tilt = sensors.getDefaultSensor(Sensor.TYPE_TILT_DETECTOR, true);
        if (tilt == null || !tilt.isWakeUpSensor()) {
            XposedBridge.log("S13GlanceV5: missing wake-up tilt sensor; no listener installed");
            return;
        }
        WakeEngine engine = new WakeEngine(ctx);
        boolean ok = sensors.registerListener(engine, tilt, SensorManager.SENSOR_DELAY_NORMAL);
        if (ok) {
            registered = true;
            XposedBridge.log("S13GlanceV5: registered=true; tilt=" + tilt.getName());
        } else {
            XposedBridge.log("S13GlanceV5: registered=false");
        }
    }

    @Override public synchronized void onSensorChanged(SensorEvent event) {
        try {
            if (power == null || power.isInteractive()) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastWake < COOLDOWN_MS) return;
            lastWake = now;
            // This is the same hidden API mechanism previously proven on S13 v3/v4.
            XposedHelpers.callMethod(power, "wakeUp", now);
            XposedBridge.log("S13GlanceV5: wrist wake requested");
            glance.showOnMainThread();
        } catch (Throwable t) {
            XposedBridge.log("S13GlanceV5: wake error");
            XposedBridge.log(t);
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
