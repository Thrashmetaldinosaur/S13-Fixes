#!/system/bin/sh

MODDIR=${0%/*}
LOG="$MODDIR/crown-volume.log"
PIDFILE="$MODDIR/crown-volume.pid"

find_rotary() {
    for e in /dev/input/event*; do
        [ -e "$e" ] || continue
        base="${e##*/}"
        name="$(cat "/sys/class/input/$base/device/name" 2>/dev/null)"
        if [ "$name" = "rotary" ]; then
            echo "$e"
            return 0
        fi
    done

    # Known fallback for this S13.
    if [ -e /dev/input/event12 ]; then
        echo /dev/input/event12
        return 0
    fi

    return 1
}

echo $$ > "$PIDFILE"
echo "$(date) service start pid=$$" >> "$LOG"

while true; do
    DEV="$(find_rotary)"

    if [ -z "$DEV" ] || [ ! -e "$DEV" ]; then
        echo "$(date) rotary device not found" >> "$LOG"
        sleep 2
        continue
    fi

    echo "$(date) listening on $DEV" >> "$LOG"

    /system/bin/getevent -l "$DEV" 2>/dev/null |
    while read type code value rest; do
        if [ "$type" = "EV_REL" ] && [ "$code" = "REL_WHEEL" ]; then
            case "$value" in
                ffffffff)
                    # Confirmed mapping on this S13:
                    # this physical direction should LOWER volume.
                    /system/bin/cmd media_session volume \
                        --stream 3 --adj raise >/dev/null 2>&1
                    ;;
                00000001)
                    # Opposite physical direction should RAISE volume.
                    /system/bin/cmd media_session volume \
                        --stream 3 --adj lower >/dev/null 2>&1
                    ;;
            esac
        fi
    done

    echo "$(date) getevent exited; retrying" >> "$LOG"
    sleep 1
done
