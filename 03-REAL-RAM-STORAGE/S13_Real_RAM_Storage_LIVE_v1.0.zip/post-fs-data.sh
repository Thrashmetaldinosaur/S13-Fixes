#!/system/bin/sh
NODE=/sys/class/misc/misc_ctrl/mems

# Best-effort early write. The node may not exist yet at post-fs-data time.
if [ -e "$NODE" ]; then
    printf '0' > "$NODE" 2>/dev/null
fi
