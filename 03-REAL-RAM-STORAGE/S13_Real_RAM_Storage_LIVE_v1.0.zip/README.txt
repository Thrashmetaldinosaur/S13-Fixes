S13 Real RAM & Storage v1.0

Purpose
-------
Disables the S13/Core 5 vendor fake-capacity profile at every boot.

The kernel exposes:
  /sys/class/misc/misc_ctrl/mems

Profile 5 (MEM_TARGET_8G_256G) fakes both RAM and storage reporting.
Profile 0 (NORMAL) restores the real hardware values.

This module writes:
  0
to:
  /sys/class/misc/misc_ctrl/mems

It does not resize, format, repartition, or modify the boot image.

Expected real hardware after the fix:
- RAM: about 2.8 GiB usable (3 GB physical)
- userdata: about 26 GiB / 27.4 GB usable partition

Verification after reboot:
  su -c 'grep MemTotal /proc/meminfo'
  su -c 'df -h /data /storage/emulated/0'

A small service.log is written inside the module directory after boot.
