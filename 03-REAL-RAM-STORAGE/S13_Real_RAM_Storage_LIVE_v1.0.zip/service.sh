#!/system/bin/sh
MODDIR=${0%/*}
NODE=/sys/class/misc/misc_ctrl/mems
LOG="$MODDIR/service.log"

i=0
while [ ! -e "$NODE" ] && [ "$i" -lt 120 ]; do
    sleep 1
    i=$((i + 1))
done

if [ -e "$NODE" ]; then
    # Force NORMAL profile. Repeat once in case vendor init reapplies the SKU profile late.
    printf '0' > "$NODE" 2>/dev/null
    sleep 10
    printf '0' > "$NODE" 2>/dev/null

    {
        echo "S13 Real RAM & Storage"
        echo "Applied: 0:NORMAL"
        echo
        grep '^MemTotal:' /proc/meminfo 2>/dev/null
        echo
        df -k /data 2>/dev/null | head -2
    } > "$LOG" 2>&1
else
    {
        echo "S13 Real RAM & Storage"
        echo "ERROR: $NODE did not appear within 120 seconds."
    } > "$LOG" 2>&1
fi
