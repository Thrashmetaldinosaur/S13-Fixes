#!/system/bin/sh

NODE=/sys/class/misc/misc_ctrl/mems

# Run as early as possible, before Android framework caches storage capacity.
i=0
while [ ! -e "$NODE" ] && [ "$i" -lt 15 ]; do
    sleep 1
    i=$((i + 1))
done

if [ -e "$NODE" ]; then
    printf 0 > "$NODE"
fi