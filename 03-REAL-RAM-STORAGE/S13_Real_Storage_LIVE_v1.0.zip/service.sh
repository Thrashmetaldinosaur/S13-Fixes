#!/system/bin/sh

NODE=/sys/class/misc/misc_ctrl/mems

# Wait until Android has completed boot.
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

# Give late vendor initialization time to finish.
sleep 10

# Reassert NORMAL several times in case the vendor writes its fake profile late.
i=0
while [ "$i" -lt 12 ]; do
    if [ -e "$NODE" ]; then
        printf 0 > "$NODE"
    fi
    sleep 5
    i=$((i + 1))
done