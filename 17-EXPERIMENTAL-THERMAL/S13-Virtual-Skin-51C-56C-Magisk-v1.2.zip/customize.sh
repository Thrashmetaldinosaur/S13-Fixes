#!/system/bin/sh
if [ "$(getprop ro.build.display.id)" != 'S13_C29_EN_V1.6_20251121' ]; then
  abort '! This package is only for S13_C29_EN_V1.6_20251121.'
fi
ui_print '- S13 VIRTUAL-SKIN 51C critical / 56C emergency'
ui_print '- Normal & charging profiles; all other thermal thresholds unchanged'
ui_print '- WARNING: elevated limits; do not wear when charging'
