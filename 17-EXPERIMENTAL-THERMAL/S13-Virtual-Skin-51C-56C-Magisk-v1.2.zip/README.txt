S13 VIRTUAL-SKIN THERMAL PROFILE -- v1.2 / 51C+56C
Supported firmware: S13_C29_EN_V1.6_20251121
Magisk module ID: s13_virtual_skin_tune

EXACT CHANGES from installed v1.1:
- thermal_info_config.json: VIRTUAL-SKIN HotThreshold[4] 49.0 -> 51.0, HotThreshold[5] 54.0 -> 56.0
- thermal_info_config_charge.json: same two threshold changes
- All other settings remain byte-identical; values retain their original JSON string types.
- Final VIRTUAL-SKIN threshold unchanged: normal 75.0, charging 57.0.
- No CPU-core, battery, charging current/voltage, kernel trip, or shutdown settings were changed.
- No CPU floor adjustment is included in this ZIP. That is a separate performance module.

IMPORTANT WARNING: 51/56 C virtual-skin thresholds are an experimental and potentially unsafe increase for a wrist-worn device. The charging profile now has only a 1 C interval between emergency (56 C) and its last threshold (57 C). VIRTUAL-SKIN is a weighted model, not a direct watch-case temperature measurement. Higher thresholds do not guarantee safety and may permit uncomfortable or harmful device temperatures. Stop use if the case feels abnormally hot. Do not wear it while charging.

INSTALL: In Magisk > Modules, install this ZIP and reboot. It replaces the existing module with the same ID. For rollback install the separate 49C/54C RESTORE v1.1 ZIP and reboot.
Firmware change: NONE. Module is a systemless overlay.
